@extends('layouts.backend')

@section('content')
    <!-- Page Content -->
    <div class="content">
        <h2 class="content-heading">Blank <small>Get Started</small></h2>
        <p>Create your own awesome project!</p>
    </div>
    <!-- END Page Content -->
@endsection
