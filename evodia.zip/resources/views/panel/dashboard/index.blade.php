@extends('panel.layouts.app')
@section("title","panel Anasayfa")
@section("content")

@endsection
