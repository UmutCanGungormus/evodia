<?php $__env->startSection("title",$langJson->menu->corporate); ?>
<?php $__env->startSection("header"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<?php $__env->startSection("menuClass","bg-dark"); ?>
<!--breadcrumbs area start-->
<div class="page-banner-section section bg-image" data-bg="assets/images/bg/breadcrumb.png">
    <div class="container">
        <div class="row">
            <div class="col">

                <div class="page-banner text-left">
                    <h2><?php echo e($langJson->menu->contact); ?></h2>
                    <ul class="page-breadcrumb">
                        <li><a href="<?php echo e(route("theme.{$langJson->routes->home}")); ?>"><?php echo e($langJson->menu->home); ?></a></li>
                        <li><?php echo e($langJson->menu->contact); ?></li>
                    </ul>
                </div>

            </div>
        </div>
    </div>
</div><!--breadcrumbs area end-->

<!--contact map start-->
<div class="contact-map-section section">
    <div class="map-area">
        <div id="googleMap">
            <iframe src="<?php echo e($thisSetting->g_map); ?>" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
        </div>
    </div>
</div><!--contact map end-->

<!--contact area start-->
<div class="contact_area mt-3">
    <div class="container">
        <div class="row">
            <div class="col-12 mt-3">
                <div class="contact_message content">
                    <h3><?php echo e($langJson->contact->contact_us); ?></h3>
                    <ul>
                        <li><i class="fa fa-fax"></i> <?php echo e($langJson->contact->address); ?> : <?php echo e($thisSetting->address); ?></li>
                        <li><i class="fa fa-envelope"></i>
                            <a href="mailto:<?php echo e($thisSetting->email); ?>"><?php echo e($thisSetting->email); ?></a></li>
                        <li>
                            <i class="fa fa-phone mr-2"></i><a href="tel:<?php echo e($thisSetting->phone_1); ?>"><?php echo e($thisSetting->phone_1); ?></a>
                        </li>
                        <li>
                            <i class="fa fa-phone mr-2"></i><a href="tel:<?php echo e($thisSetting->phone_2); ?>"><?php echo e($thisSetting->phone_2); ?></a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-12 mt-3">
                <div class="contact-form-wrap">
                    <h3 class="contact-title">Write Us</h3>
                    <form id="contact-form" action="assets/php/mail.php" method="post">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="name-fild-padding mb-sm-30 mb-xs-30">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="contact-form-style mb-20">
                                                <label class="fild-name">Name</label>
                                                <input name="name" placeholder="" type="text">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="contact-form-style mb-20">
                                                <label class="fild-name">Email</label>
                                                <input name="email" placeholder="" type="email">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="contact-form-style bl">
                                    <label class="fild-name pl-15">Message</label>
                                    <textarea class="pl-15" name="message" placeholder="Type your message here.."></textarea>
                                    <button class="btn" type="submit"><span>Send message</span></button>
                                </div>
                            </div>
                        </div>
                    </form>
                    <p class="form-messege"></p>
                </div>
            </div>
        </div>
    </div>
</div><!--contact area end-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/mutfakyapim.com.tr/evodia.mutfakyapim.com.tr/resources/views/theme/contact/index.blade.php ENDPATH**/ ?>