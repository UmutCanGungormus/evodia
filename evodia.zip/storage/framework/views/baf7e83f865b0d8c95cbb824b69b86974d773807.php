<?php $__env->startSection("title",$langJson->menu->products); ?>
<?php $__env->startSection("header"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<?php $__env->startSection("menuClass","bg-dark"); ?>
<div class="page-banner-section section bg-image" data-bg="assets/images/bg/breadcrumb.png">
    <div class="container">
        <div class="row">
            <div class="col">

                <div class="page-banner text-left">
                    <h2><?php echo e($search); ?></h2>
                    <ul class="page-breadcrumb">
                        <li><a href="index.html"><?php echo e($langJson->menu->home); ?></a></li>
                        <li><?php echo e($search); ?></li>
                    </ul>
                </div>

            </div>
        </div>
    </div>
</div><!-- Page Banner Section End --><!-- Shop Section Start -->
<div class="shop-section section pt-60 pt-lg-40 pt-md-30 pt-sm-20 pt-xs-30  pb-70 pb-lg-50 pb-md-40 pb-sm-60 pb-xs-50">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="shop-area">
                    <div class="row">
                        <div class="col-12">
                            <!-- Grid & List View Start -->
                            <div class="shop-topbar-wrapper d-flex justify-content-between align-items-center">
                                <div class="grid-list-option d-flex">
                                    <ul class="nav">
                                        <li>
                                            <a data-toggle="tab" href="#grid"><i class="fa fa-th"></i></a>
                                        </li>
                                        <li>
                                            <a class="active show" data-toggle="tab" href="#list" class=""><i class="fa fa-th-list"></i></a>
                                        </li>
                                    </ul>
                                    <p><?php echo e((empty($viewData->products->data)?"0":count((array)$viewData->products->data))); ?> <?php echo e($langJson->category->showing); ?></p>
                                </div>
                                <!--Toolbar Short Area Start-->
                                <div class="toolbar-short-area d-md-flex align-items-center">
                                    <div class="toolbar-shorter ">
                                        <select name="orderby" class="order-by wide" id="short">
                                            <option <?php echo e((Cookie::get("order")=="desc" && Cookie::get("column")=="id" ?"selected":"")); ?> value="id,desc"><?php echo e($langJson->select_order->new); ?></option>
                                            <option <?php echo e((Cookie::get("order")=="asc" && Cookie::get("column")=="id" ?"selected":"")); ?> value="id,asc"><?php echo e($langJson->select_order->old); ?></option>
                                            <option <?php echo e((Cookie::get("order")=="asc" && Cookie::get("column")=="price->{$lang}" ?"selected":"")); ?> value="price-><?php echo e($lang); ?>,asc"><?php echo e($langJson->select_order->cheap); ?></option>
                                            <option <?php echo e((Cookie::get("order")=="desc" && Cookie::get("column")=="price->{$lang}" ?"selected":"")); ?> value="price-><?php echo e($lang); ?>,desc"><?php echo e($langJson->select_order->expensive); ?></option>
                                        </select>
                                    </div>
                                </div>
                                <!--Toolbar Short Area End-->
                            </div>
                            <!-- Grid & List View End -->
                        </div>
                    </div>
                    <div class="row">

                        <div class="col-12">
                            <?php if(count((array)$viewData->products)>0): ?>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="shop-product">
                                            <div class="render-data">
                                                <div id="myTabContent-2" class="tab-content">
                                                    <div id="grid" class="tab-pane fade">
                                                        <div class="product-grid-view">
                                                            <div class="row">
                                                                <?php $__currentLoopData = $viewData->products->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <div class="col-lg-4 col-md-6 col-sm-6">
                                                                        <!--  Single Grid product Start -->
                                                                        <div class="single-grid-product mb-40">
                                                                            <div class="product-image">
                                                                                <?php if($product->isDiscount): ?>
                                                                                    <div class="product-label">
                                                                                        <span><?php echo e($langJson->home->discount); ?></span>
                                                                                    </div>
                                                                                <?php endif; ?>

                                                                                <a href="<?php echo e(route("theme.{$langJson->routes->product}",$product->seo_url->$lang)); ?>">
                                                                                    <img src="<?php echo e(asset("storage/{$product->cover_photo->img_url}")); ?>" class="img-fluid" alt="<?php echo e($product->title->$lang); ?>"></a>
                                                                                <div class="product-action">
                                                                                    <ul>
                                                                                        <li>
                                                                                            <a href="<?php echo e(route("theme.{$langJson->routes->product}",$product->seo_url->$lang)); ?>"><i class="fa fa-search  mt-2"></i></a>
                                                                                        </li>

                                                                                        <li>
                                                                                            <a data-id="<?php echo e($product->id); ?>" class="addToFavourite" href="javascript:void(0)" title="<?php echo e($langJson->home->favourite); ?>"><i class="fa fa-heart  mt-2"></i></a>
                                                                                        </li>
                                                                                    </ul>
                                                                                </div>
                                                                            </div>
                                                                            <div class="product-content">
                                                                                <h3 class="title">
                                                                                    <a href="<?php echo e(route("theme.{$langJson->routes->product}",$product->seo_url->$lang)); ?>"><?php echo e($product->title->$lang); ?></a>
                                                                                </h3>
                                                                                <p class="product-price">
                                                                                    <span class="discounted-price"><?php echo e($product->price->$lang); ?> <?php echo e($langJson->home->price); ?></span>
                                                                                </p>
                                                                            </div>
                                                                        </div>
                                                                        <!--  Single Grid product End -->
                                                                    </div>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div id="list" class="tab-pane fade active show">
                                                        <div class="product-list-view">
                                                            <!-- Single List Product Start -->
                                                            <?php $__currentLoopData = $viewData->products->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <div class="product-list-item mb-40">
                                                                    <div class="row">
                                                                        <div class="col-md-4 col-sm-6">
                                                                            <div class="single-grid-product">
                                                                                <div class="product-image">
                                                                                    <?php if($product->isDiscount): ?>
                                                                                        <div class="product-label">
                                                                                            <span><?php echo e($langJson->home->discount); ?></span>
                                                                                        </div>
                                                                                    <?php endif; ?>

                                                                                    <a href="<?php echo e(route("theme.{$langJson->routes->product}",$product->seo_url->$lang)); ?>">
                                                                                        <img src="<?php echo e(asset("storage/{$product->cover_photo->img_url}")); ?>" class="img-fluid" alt="<?php echo e($product->title->$lang); ?>"></a>

                                                                                    <div class="product-action">
                                                                                        <ul>
                                                                                            <li>
                                                                                                <a href="<?php echo e(route("theme.{$langJson->routes->product}",$product->seo_url->$lang)); ?>"><i class="fa fa-search  mt-2"></i></a>
                                                                                            </li>

                                                                                            <li>
                                                                                                <a data-id="<?php echo e($product->id); ?>" class="addToFavourite" href="javascript:void(0)" title="<?php echo e($langJson->home->favourite); ?>"><i class="fa fa-heart  mt-2"></i></a>
                                                                                            </li>
                                                                                        </ul>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-8 col-sm-6">
                                                                            <div class="product-content-shop-list">
                                                                                <div class="product-content">
                                                                                    <h3 class="title">
                                                                                        <a href="<?php echo e(route("theme.{$langJson->routes->product}",$product->seo_url->$lang)); ?>"><?php echo e($product->title->$lang); ?></a>
                                                                                    </h3>
                                                                                    <p class="product-price">
                                                                                        <span class="discounted-price"><?php echo e($product->price->$lang); ?> <?php echo e($langJson->home->price); ?></span>
                                                                                    </p>
                                                                                    <p class="product-desc"><?php echo e(Str::words($product->description->$lang,"3","...")); ?></p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <!-- Single List Product Start -->
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-30 mb-sm-40 mb-xs-30">
                                    <div class="col">
                                        <ul class="page-pagination">
                                            <?php echo $links; ?>

                                        </ul>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-danger"><?php echo e($langJson->alert->no_product); ?></div>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><!-- Shop Section End -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection("footer"); ?>
    <script>
        $(document).ready(function () {
            $(document).on("change", ".order-by", function () {
                let value = $(this).val();
                value = value.split(",")
                setCookie("search_column",value[0]);
                setCookie("search_order",value[1])
                $.ajax({
                    "url": "<?php echo e(route("theme.{$langJson->routes->render_search}")); ?>",
                    "data": {"search_column": value[0], "search_order": value[1],"search":"<?php echo e($search); ?>"},
                    "type": "POST"
                }).done(function (response) {

                    $(".render-data").html(response)
                })
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\evodia\resources\views/theme/search/index.blade.php ENDPATH**/ ?>