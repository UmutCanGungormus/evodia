<?php $__env->startSection("title",$langJson->menu->home); ?>
<?php $__env->startSection("header"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<?php $__env->startSection("menuClass","header_two header_transparent"); ?>

    <!--slider area start-->
    <section class="slider_section mb-100">
        <div class="slider_area owl-carousel">
            <?php $__currentLoopData = $viewData->slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="single_slider d-flex align-items-center"
                     data-bgimg="<?php echo e(asset("storage/{$slide->img_url->$lang}")); ?>">
                    <div class="container">
                        <div class="row">
                            <div class="col-12">
                                <div class="slider_content text-center">
                                    <h1 class="mb-3 text-white"><?php echo e($slide->title->$lang); ?></h1>
                                    <a href="<?php echo e((!empty($slide->url->$lang)?$slide->url->$lang:"#")); ?>"><?php echo e($langJson->home->examine); ?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <!--slider area end-->
    <!--banner area start-->
    <div class="banner_area">
        <div class="container-fluid p-0">
            <div class="row no-gutters">
                <?php $__currentLoopData = $viewData->banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-sm-12 col-md-6 ol-lg-4 col-xl-4">
                        <div class="single_banner">
                            <div class="banner_thumb">
                                <a href="shop.html"><img src="<?php echo e(asset("storage/{$item->img_url->$lang}")); ?>"
                                                         alt="<?php echo e($item->title->$lang); ?>"></a>
                                <div class="banner_text2 text-center">
                                    <h4 class="text-white"><?php echo e($item->title->$lang); ?></h4>
                                    <a href="shop.html"><?php echo e($langJson->home->examine); ?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!--banner area end-->

    <!--product area start-->
    <div class="product_area  mb-95">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title product_shop_title">
                        <h2><?php echo e($langJson->home->trendProduct); ?></h2>
                    </div>

                </div>
            </div>
            <div class="row">
                <div class="product_carousel product_column5 owl-carousel">
                    <?php $__currentLoopData = $viewData->homeProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3">
                            <div class="product_items">
                                <article class="single_product">
                                    <figure>
                                        <div class="product_thumb">
                                            <a class="primary_img" href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"><img
                                                    src="<?php echo e(asset("storage/{$item->cover_photo->img_url}")); ?>"
                                                    alt="<?php echo e($item->title->$lang); ?>"></a>
                                            <?php if($item->isDiscount): ?>
                                                <div class="label_product">
                                                    <span class="label_sale"><?php echo e($langJson->home->discount); ?></span>
                                                </div>
                                            <?php endif; ?>
                                            <div class="action_links">
                                                <ul>
                                                    <li class="quick_button"><a href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"
                                                                                title="<?php echo e($langJson->home->examine); ?>"> <span
                                                                class="pe-7s-search"></span></a></li>
                                                    <li class="wishlist"><a data-id="<?php echo e($item->id); ?>"
                                                                            class="addToFavourite" href="javascript:void(0)"
                                                                            title="<?php echo e($langJson->home->favourite); ?>"><span
                                                                class="pe-7s-like"></span></a>
                                                    </li>

                                                </ul>
                                            </div>
                                        </div>
                                        <figcaption class="product_content">
                                            <div class="product_content_inner">
                                                <?php if(!empty($item->category)): ?>
                                                    <h6 class="product_name">
                                                        <?php $__currentLoopData = $item->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <a href=""><?php echo e($category->title->$lang); ?> <?php echo e((count((array)$item->category)-1!=$cat_key?"/":"")); ?></a>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </h6>
                                                <?php endif; ?>
                                                <h4 class="product_name"><a
                                                        href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"><?php echo e($item->title->$lang); ?></a>
                                                </h4>
                                                <div class="price_box">
                                                    <span
                                                        class="current_price"><?php echo e($item->price->$lang); ?> <?php echo e($langJson->home->price); ?></span>
                                                </div>
                                            </div>
                                            <div class="add_to_cart">
                                                <a href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"><?php echo e($langJson->home->examine); ?></a>
                                            </div>
                                        </figcaption>
                                    </figure>
                                </article>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <!--product area end-->
    <!--product area start-->
    <div class="product_area  mb-95">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title product_shop_title">
                        <h2><?php echo e($langJson->home->isComing); ?></h2>
                    </div>

                </div>
            </div>
            <div class="row">
                <div class="product_carousel product_column5 owl-carousel">
                    <?php $__currentLoopData = $viewData->discountProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3">
                            <div class="product_items">
                                <article class="single_product">
                                    <figure>
                                        <div class="product_thumb">
                                            <a class="primary_img" href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"><img
                                                    src="<?php echo e(asset("storage/{$item->cover_photo->img_url}")); ?>"
                                                    alt="<?php echo e($item->title->$lang); ?>"></a>
                                            <?php if($item->isDiscount): ?>
                                                <div class="label_product">
                                                    <span class="label_sale"><?php echo e($langJson->home->discount); ?></span>
                                                </div>
                                            <?php endif; ?>
                                            <div class="action_links">
                                                <ul>
                                                    <li class="quick_button"><a href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"
                                                                                title="<?php echo e($langJson->home->examine); ?>"> <span
                                                                class="pe-7s-search"></span></a></li>
                                                    <li class="wishlist"><a data-id="<?php echo e($item->id); ?>"
                                                                            class="addToFavourite" href="javascript:void(0)"
                                                                            title="<?php echo e($langJson->home->favourite); ?>"><span
                                                                class="pe-7s-like"></span></a>
                                                    </li>

                                                </ul>
                                            </div>
                                        </div>
                                        <figcaption class="product_content">
                                            <div class="product_content_inner">
                                                <?php if(!empty($item->category)): ?>
                                                    <h6 class="product_name">
                                                        <?php $__currentLoopData = $item->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <a href=""><?php echo e($category->title->$lang); ?> <?php echo e((count((array)$item->category)-1!=$cat_key?"/":"")); ?></a>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </h6>
                                                <?php endif; ?>
                                                <h4 class="product_name"><a
                                                        href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"><?php echo e($item->title->$lang); ?></a>
                                                </h4>
                                                <div class="price_box">
                                                    <span
                                                        class="current_price"><?php echo e($item->price->$lang); ?> <?php echo e($langJson->home->price); ?></span>
                                                </div>
                                            </div>
                                            <div class="add_to_cart">
                                                <a href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"><?php echo e($langJson->home->examine); ?></a>
                                            </div>
                                        </figcaption>
                                    </figure>
                                </article>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <!--product area end-->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('theme.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\unique\resources\views/theme/home/index.blade.php ENDPATH**/ ?>