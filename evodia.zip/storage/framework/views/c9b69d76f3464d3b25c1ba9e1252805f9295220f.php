<?php $__env->startSection("title","panel Ayarlar"); ?>
<?php $__env->startSection("header"); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css"
          integrity="sha512-nMNlpuaDPrqlEls3IX/Q56H36qvBASwb3ipuo3MxeWbsQB1881ox0cRv7UPTgBlriqoynt35KjEwgGUeUXIPnw=="
          crossorigin="anonymous"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <!-- Page body start -->
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <!-- Material tab card start -->
                            <div class="card">
                                <div class="card-header">
                                    <h5>Site Ayarlarınızı Ekleyin</h5>
                                </div>
                                <div class="card-block">
                                    <!-- Row start -->
                                    <div class="row m-b-30">
                                        <div class="col-12">
                                            <!-- Nav tabs -->
                                            <ul class="nav nav-tabs md-tabs" role="tablist">
                                                <?php
                                                    $i=0;
                                                ?>
                                                <?php $__currentLoopData = $data->content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <li class="nav-item">
                                                        <a class="nav-link <?=($i == 0 ? "active" : "")?>"
                                                           data-toggle="tab" href="#<?php echo e($key); ?>"
                                                           role="tab"><?php echo e($key); ?></a>
                                                        <div class="slide"></div>
                                                    </li>
                                                    <?php
                                                        $i++;
                                                    ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </ul>
                                            <!-- Tab panes -->
                                            <form enctype="multipart/form-data" class="form-material" method="POST"
                                                  action="<?php echo e(route("panel.settings.json",$data->lang)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <div class="tab-content card-block">
                                                    <?php
                                                        $i=0;
                                                    ?>
                                                    <?php $__currentLoopData = $data->content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="tab-pane <?=($i == 0 ? "active show" : "")?>"
                                                             id="<?php echo e($key); ?>" role="tabpanel">
                                                            <div class="row">
                                                                <?php $__currentLoopData = (array)$item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if(is_object($value)): ?>
                                                                        <label for=""><?php echo e($value->top); ?></label>
                                                                        <input class="form-control" type="text"
                                                                               name="<?php echo e($key); ?>[<?php echo e($v_key); ?>][value]"
                                                                               value="<?php echo e($value->value); ?>">
                                                                    <?php else: ?>
                                                                        <label for=""><?php echo e($v_key); ?></label>
                                                                        <input class="form-control" type="text"
                                                                               name="<?php echo e($key); ?>[<?php echo e($v_key); ?>]"
                                                                               value="<?php echo e($value); ?>">
                                                                        <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </div>
                                                        </div>
                                                        <?php
                                                            $i++;
                                                        ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                                <div
                                                    class="col-12 col-sm-12 col-md-12 col-lg-4 col-xl-4 offset-0 offset-sm-0 offset-md-0 offset-lg-8 offset-xl-8 text-right">
                                                    <input type="submit" class="btn btn-primary rounded" value="Kaydet">
                                                    <a href="<?php echo e(route("panel.settings.index")); ?>"
                                                       class="btn btn-danger rounded">İptal</a>
                                                </div>
                                            </form>

                                        </div>

                                    </div>
                                    <!-- Row end -->
                                </div>
                            </div>
                            <!-- Material tab card end -->
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("footer"); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"
            integrity="sha512-2ImtlRlf2VVmiGZsjm9bEyhjGW4dU7B6TNwh/hx/iSByxNENtj3WVE6o/9Lj4TJeVXPi4bnOIMXFIJJAeufa0A=="
            crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/i18n/tr.min.js"
            integrity="sha512-2386tYyq9+EGdON3UecxdBTaO5lnboGy/rq93uHoVeBqxHAPvjnQsXJMfKBJck63KwQ3xidTlPBDvW3DR+Yo+Q=="
            crossorigin="anonymous"></script>
    <script>
        $(document).ready(function () {

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\unique\resources\views/panel/settings/json/index.blade.php ENDPATH**/ ?>
