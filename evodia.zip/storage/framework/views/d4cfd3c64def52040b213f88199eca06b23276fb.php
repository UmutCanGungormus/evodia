<?php $__env->startSection("title",$langJson->menu->products); ?>
<?php $__env->startSection("header"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>

        <!-- Page Banner Section Start -->
        <div class="page-banner-section section bg-image" data-bg="assets/images/bg/breadcrumb.png">
            <div class="container">
                <div class="row">
                    <div class="col">

                        <div class="page-banner text-left">
                            <h2><?php echo e($langJson->menu->basket); ?></h2>
                            <ul class="page-breadcrumb">
                                <li><a href="<?php echo e(route("theme.{$langJson->routes->home}")); ?>"><?php echo e($langJson->menu->home); ?></a></li>
                                <li><?php echo e($langJson->menu->basket); ?></li>
                            </ul>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- Page Banner Section End -->
        <!--Cart section start-->
        <div class="cart-section section pt-90 pt-lg-70 pt-md-60 pt-sm-50 pt-xs-45  pb-70 pb-lg-50 pb-md-40 pb-sm-30 pb-xs-20">
            <div class="container">
                <div class="row">

                    <div class="col-12">
                        <!-- Cart Table -->
                        <div class="cart-table table-responsive mb-30">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th class="pro-thumbnail">Image</th>
                                        <th class="pro-title">Product</th>
                                        <th class="pro-price">Price</th>
                                        <th class="pro-quantity">Quantity</th>
                                        <th class="pro-subtotal">Total</th>
                                        <th class="pro-remove">Remove</th>
                                    </tr>
                                </thead>
                                  <tbody>
                                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="product_remove"><a href="javascript:void(0)" class="delete-cart-item" data-id="<?php echo e($item->id); ?>"><i
                                                    class="fa fa-trash "></i></a></td>
                                        <td class="pro-thumbnail"><a href="#"><img
                                                    src="<?php echo e(asset("storage/{$item->associatedModel->cover_photo->img_url}")); ?>"
                                                    alt=""></a></td>
                                        <td class="product_name"><a href="<?php echo e(route("theme.{$langJson->routes->product}",$item->associatedModel->seo_url->$lang)); ?>"><?php echo e($item->name->$lang); ?></a></td>
                                        <td class="product-price"><?php echo e($item->price." ".$langJson->home->price); ?></td>
                                        <td class="product_quantity"><label>Adet</label> <input min="1" max="100"
                                                                                                value="<?php echo e($item->quantity); ?>"
                                                                                                type="number"></td>
                                        <td class="product_total"><?php echo e($item->price*$item->quantity." ".$langJson->home->price); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="row">

                            <div class="col-lg-6 col-12 mb-5">
                                <!-- Calculate Shipping -->
                                <div class="calculate-shipping">
                                    <h4>Calculate Shipping</h4>
                                    <form action="#">
                                        <div class="row">
                                            <div class="col-md-6 col-12 mb-25">
                                                <select class="nice-select">
                                                    <option>Bangladesh</option>
                                                    <option>China</option>
                                                    <option>country</option>
                                                    <option>India</option>
                                                    <option>Japan</option>
                                                </select>
                                            </div>
                                            <div class="col-md-6 col-12 mb-25">
                                                <select class="nice-select">
                                                    <option>Dhaka</option>
                                                    <option>Barisal</option>
                                                    <option>Khulna</option>
                                                    <option>Comilla</option>
                                                    <option>Chittagong</option>
                                                </select>
                                            </div>
                                            <div class="col-md-6 col-12 mb-25">
                                                <input type="text" placeholder="Postcode / Zip">
                                            </div>
                                            <div class="col-md-6 col-12 mb-25">
                                                <button class="btn">Estimate</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <!-- Discount Coupon -->
                                <div class="discount-coupon">
                                    <h4>Discount Coupon Code</h4>
                                    <form action="#">
                                        <div class="row">
                                            <div class="col-md-6 col-12 mb-25">
                                                <input type="text" placeholder="Coupon Code">
                                            </div>
                                            <div class="col-md-6 col-12 mb-25">
                                                <button class="btn">Apply Code</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <!-- Cart Summary -->
                            <div class="col-lg-6 col-12 mb-30 d-flex">
                                <div class="cart-summary">
                                    <div class="cart-summary-wrap">
                                        <h4>Cart Summary</h4>
                                        <p>Sub Total <span>$75.00</span></p>
                                        <p>Shipping Cost <span>$00.00</span></p>
                                        <h2>Grand Total <span>$75.00</span></h2>
                                    </div>
                                    <div class="cart-summary-button">
                                        <button class="btn">Checkout</button>
                                        <button class="btn">Update Cart</button>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>

                </div>
            </div>
        </div>
        <!--Cart section end-->
<!--breadcrumbs area start-->
<div class="breadcrumbs_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_content">
                    <h3>Sepet</h3>
                    <ul>
                        <li><a href="index.html">Anasayfa</a></li>
                        <li>Alışveriş Sepeti</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!--breadcrumbs area end-->

<!--shopping cart area start -->
<div class="shopping_cart_area">
    <div class="container">
        <form action="#">
            <div class="row">
                <div class="col-12">
                    <div class="table_desc">
                        <div class="cart_page table-responsive">
                            <table>
                                <thead>
                                <tr>
                                    <th class="product_remove">Sil</th>
                                    <th class="product_thumb">Resim</th>
                                    <th class="product_name">Ürün</th>
                                    <th class="product-price">Fiyat</th>
                                    <th class="product_quantity">Adet</th>
                                    <th class="product_total">Toplam</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="product_remove"><a href="javascript:void(0)" class="delete-cart-item" data-id="<?php echo e($item->id); ?>"><i
                                                    class="fa fa-trash "></i></a></td>
                                        <td class="product_thumb"><a href="#"><img
                                                    src="<?php echo e(asset("storage/{$item->associatedModel->cover_photo->img_url}")); ?>"
                                                    alt=""></a></td>
                                        <td class="product_name"><a href="<?php echo e(route("theme.{$langJson->routes->product}",$item->associatedModel->seo_url->$lang)); ?>"><?php echo e($item->name->$lang); ?></a></td>
                                        <td class="product-price"><?php echo e($item->price." ".$langJson->home->price); ?></td>
                                        <td class="product_quantity"><label>Adet</label> <input min="1" max="100"
                                                                                                value="<?php echo e($item->quantity); ?>"
                                                                                                type="number"></td>
                                        <td class="product_total"><?php echo e($item->price*$item->quantity." ".$langJson->home->price); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!--coupon code area start-->
            <div class="coupon_area">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="coupon_code left">
                            <h3>Kupon</h3>
                            <div class="coupon_inner">
                                <p>Sahip Olduğunuz Kuponlarınızı Sepetinizde Kullanabilirsiniz.</p>
                                <input placeholder="Kuponu Kodu" type="text">
                                <button type="submit">Kuponu Uygula</button>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="coupon_code right">
                            <h3>Sepet Toplamı</h3>
                            <div class="coupon_inner">
                                <div class="cart_subtotal">
                                    <p>Ara Toplam</p>
                                    <p class="cart_amount"><?php echo e(\Cart::getTotal() ." ". $langJson->home->price); ?></p>
                                </div>
                                <div class="cart_subtotal d-none">
                                    <p>Kargo</p>
                                    <p class="cart_amount"><span>Sabit Fiyat:</span> £255.00</p>
                                </div>

                                <div class="cart_subtotal">
                                    <p>Toplam</p>
                                    <p class="cart_amount"><?php echo e(\Cart::getTotal() ." ". $langJson->home->price); ?></p>
                                </div>
                                <div class="checkout_btn">
                                    <a href="#">Alışverişi Tamamla</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--coupon code area end-->
        </form>
    </div>
</div>
<!--shopping cart area end -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection("footer"); ?>
    <script>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/mutfakyapim.com.tr/evodia.mutfakyapim.com.tr/resources/views/theme/basket/index.blade.php ENDPATH**/ ?>