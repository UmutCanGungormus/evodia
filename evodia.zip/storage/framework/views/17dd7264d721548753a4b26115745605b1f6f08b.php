<div class="mini_cart">
    <div class="cart_gallery">
        <div class="cart_close">
            <div class="cart_text">
                <h3><?php echo e($langJson->menu->basket); ?></h3>
            </div>
            <div class="mini_cart_close">
                <a href="javascript:void(0)"><i class="ion-android-close"></i></a>
            </div>
        </div>
        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="cart_item">
                <div class="cart_img">
                    <a href="<?php echo e(route("theme.{$langJson->routes->product}",$cartItem->associatedModel->seo_url->$lang)); ?>"><img
                            src="<?php echo e(asset("storage/{$cartItem->associatedModel->cover_photo->img_url}")); ?>"
                            alt=""></a>
                </div>
                <div class="cart_info">
                    <a href="#"><?php echo e($cartItem->name->$lang); ?></a>
                    <p><?php echo e($cartItem->quantity); ?> x
                        <span> <?php echo e($cartItem->associatedModel->price->$lang." ".$langJson->home->price); ?></span>
                    </p>
                </div>
                <div class="cart_remove">
                    <a class="delete-cart-item" data-id="<?php echo e($cartItem->id); ?>" href="javascript:void(0)"><i
                            class="ion-ios-close-outline"></i></a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <div class="mini_cart_table_div bg-light">
        <div class="mini_cart_table">
            <div class="cart_table_border">
                <div class="cart_total">
                    <span><?php echo e($langJson->home->sub_total); ?>:</span>
                    <span class="price"><?php echo e(\Cart::getSubTotal()." ".$langJson->home->price); ?></span>
                </div>
                <div class="cart_total mt-10">
                    <span><?php echo e($langJson->home->total); ?>:</span>
                    <span class="price"><?php echo e(\Cart::getTotal()." ".$langJson->home->price); ?></span>
                </div>
            </div>
        </div>
        <div class="mini_cart_footer">
            <div class="cart_button">
                <a href="<?php echo e(route("theme.{$langJson->routes->basket}")); ?>"><i class="fa fa-shopping-cart"></i> <?php echo e($langJson->home->basket_go); ?></a>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\unique\resources\views/theme/basket/render.blade.php ENDPATH**/ ?>