<?php $__env->startSection("title",$langJson->menu->products); ?>
<?php $__env->startSection("header"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <!-- Page Banner Section Start -->
    <div class="page-banner-section section bg-image" data-bg="assets/images/bg/breadcrumb.png">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="page-banner text-left">
                        <h2><?php echo e($viewData->item->title->$lang); ?></h2>
                        <ul class="page-breadcrumb">
                            <li><a href="index.html"><?php echo e($langJson->menu->home); ?></a></li>
                            <li><?php echo e($viewData->item->title->$lang); ?></li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- Page Banner Section End -->
    <!-- Single Product Section Start -->
    <div class="single-product-section section pt-60 pt-lg-40 pt-md-30 pt-sm-20 pt-xs-25 pb-100 pb-lg-80 pb-md-70 pb-sm-30 pb-xs-20">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="shop-area">
                        <div class="row">
                            <div class="col-md-6 pr-35 pr-lg-15 pr-md-15 pr-sm-15 pr-xs-15">
                                <!-- Product Details Left -->
                                <div class="product-details-left">
                                    <div class="product-details-images">
                                        <?php $__currentLoopData = $viewData->products->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="lg-image">
                                                <img src="<?php echo e(asset("storage/{$photo->img_url}")); ?>" alt="<?php echo e($viewData->item->title->$lang); ?>">
                                                <a href="<?php echo e(asset("storage/{$photo->img_url}")); ?>" class="popup-img venobox" data-gall="myGallery"><i class="fa fa-expand"></i></a>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="product-details-thumbs">
                                        <?php $__currentLoopData = $viewData->products->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="sm-image">
                                                <img src="<?php echo e(asset("storage/{$photo->img_url}")); ?>" alt="<?php echo e($viewData->item->title->$lang); ?>">
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>
                                </div>
                                <!--Product Details Left -->
                            </div>
                            <div class="col-md-6">
                                <!--Product Details Content Start-->
                                <div class="product-details-content">

                                    <h2><?php echo e($viewData->item->title->$lang); ?></h2>

                                    <div class="single-product-price">
                                        <span class="price new-price"><?php echo e(number_format($viewData->item->price->$lang,"2")); ?> <?php echo e($langJson->home->price); ?></span>
                                    </div>
                                    <div class="product-description">
                                        <p><?php echo e(Str::words($viewData->item->description->$lang,"3","...")); ?></p>
                                    </div>
                                    <div class="single-product-quantity">
                                        <div class="product-variants">
                                            <div class="product-variants-item ml-0">
                                                <?php if(!empty($viewData->products->option_categories)): ?>
                                                    <span class="control-label"><?php echo e($langJson->products->options); ?></span>

                                                    <h3></h3>
                                                    <?php $__currentLoopData = $viewData->products->option_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="input-group">
                                                            <label class="input-group-text" for="select-<?php echo e($key); ?>"><?php echo e($option->title->$lang); ?></label>
                                                            <select class="form-select product-option" id="select-<?php echo e($key); ?>">
                                                                <option data-name="<?php echo e($option->title->$lang); ?>" value="0"><?php echo e($langJson->products->select); ?></option>
                                                                <?php $__currentLoopData = $viewData->products->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($opt->category_id==$option->id): ?>
                                                                        <option value="<?php echo e($opt->id); ?>" data-name="<?php echo e($option->title->$lang); ?>" <?php echo e(($opt->stock->$lang<=0?"disabled":"")); ?>><?php echo e($opt->title->$lang); ?> </option>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>

                                            </div>
                                        </div>
                                        <div class="product-quantity">
                                            <label class="d-none"><?php echo e($langJson->products->count); ?></label>
                                            <input class="product-count" min="1" max="100" value="1" type="number">
                                        </div>
                                        <div class="add-to-link">
                                            <button class="button btn rounded-0 add-to-basket" type="button">
                                                <i class="fa fa-shopping-bag"></i> <?php echo e($langJson->products->add_basket); ?>

                                            </button>

                                        </div>
                                    </div>
                                    <div class="wishlist-compare-btn">
                                        <a href="#" class="wishlist-btn"></a>
                                    </div>
                                    <div class="product-meta">
                                         <span class="posted-in">
                                             <?php echo e($langJson->menu->category); ?>:
                                            <?php $__currentLoopData = $viewData->products->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                 <a class="ml-1" href="<?php echo e(route("theme.{$langJson->routes->category}",$category->seo_url->$lang)); ?>"><?php echo e($category->title->$lang); ?> <?php echo e(($key%2==0 ? (count((array)$viewData->products->category)>1?"/":""):"")); ?></a>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         </span>

                                    </div>
                                </div>
                                <!--Product Details Content End-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Single Product Section End -->

    <!--Product Description Review Section Start-->
    <div class="product-description-review-section section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="product-review-tab section">
                        <!--Review And Description Tab Menu Start-->
                        <ul class="nav dec-and-review-menu">
                            <li>
                                <a class="active" data-toggle="tab" href="#info" role="tab" aria-controls="info" aria-selected="false"><?php echo e($langJson->products->description); ?></a>
                            </li>
                            <li>
                                <a data-toggle="tab" href="#sheet" role="tab" aria-controls="sheet" aria-selected="false"><?php echo e($langJson->products->features); ?></a>
                            </li>

                        </ul>
                        <!--Review And Description Tab Menu End-->
                        <!--Review And Description Tab Content Start-->
                        <div class="tab-content product-review-content-tab" id="myTabContent-4">
                            <div class="tab-pane fade show active" id="info" role="tabpanel">
                                <div class="product_info_content">
                                    <p><?php echo e($viewData->item->description->$lang); ?></p>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="sheet" role="tabpanel">

                                <div class="product_info_content">
                                    <p><?php echo e($viewData->item->features->$lang); ?></p>
                                </div>
                            </div>
                        </div>
                        <!--Review And Description Tab Content End-->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Product Description Review Section Start-->

    <!--Product section start-->
    <div class="product-section section pt-100 pt-lg-80 pt-md-70 pt-sm-60 pt-xs-50 pb-55 pb-lg-35 pb-md-25 pb-sm-15 pb-xs-5">
        <div class="container">

            <div class="row">
                <div class="col">
                    <div class="section-title text-center mb-50 mb-xs-20">
                        <h2><?php echo e($langJson->home->isComing); ?></h2>
                    </div>
                </div>
            </div>
            <div class="row product-slider">
                <?php $__currentLoopData = $viewData->homeProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col">
                        <!--  Single Grid product Start -->
                        <div class="single-grid-product mb-40">
                            <div class="product-image">
                                <?php if($item->isDiscount): ?>
                                    <div class="product-label">
                                        <span><?php echo e($langJson->home->discount); ?></span>
                                    </div>
                                <?php endif; ?>

                                <a href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>">
                                    <img src="<?php echo e(asset("storage/{$item->cover_photo->img_url}")); ?>" class="img-fluid" alt="<?php echo e($item->title->$lang); ?>">
                                </a>

                                <div class="product-action">
                                    <ul>
                                        <li><a href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"><i class="fa fa-search  mt-2"></i></a></li>

                                        <li><a data-id="<?php echo e($item->id); ?>" class="addToFavourite" href="javascript:void(0)" title="<?php echo e($langJson->home->favourite); ?>"><i class="fa fa-heart  mt-2"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product-content">
                                <h3 class="title"> <a href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"><?php echo e($item->title->$lang); ?></a></h3>
                                <p class="product-price"><span class="discounted-price"><?php echo e($item->price->$lang); ?> <?php echo e($langJson->home->price); ?></span>
                                </p>
                            </div>
                        </div>
                        <!--  Single Grid product End -->
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </div>
    <!--Product section end-->
    <!--Product section start-->
    <div class="product-section section pt-100 pt-lg-80 pt-md-70 pt-sm-60 pt-xs-50 pb-55 pb-lg-35 pb-md-25 pb-sm-15 pb-xs-5">
        <div class="container">

            <div class="row">
                <div class="col">
                    <div class="section-title text-center mb-50 mb-xs-20">
                        <h2><?php echo e($langJson->home->trendProduct); ?></h2>
                    </div>
                </div>
            </div>
            <div class="row product-slider">
                <?php $__currentLoopData = $viewData->discountProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col">
                        <!--  Single Grid product Start -->
                        <div class="single-grid-product mb-40">
                            <div class="product-image">
                                <?php if($item->isDiscount): ?>
                                    <div class="product-label">
                                        <span><?php echo e($langJson->home->discount); ?></span>
                                    </div>
                                <?php endif; ?>

                                <a href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>">
                                    <img src="<?php echo e(asset("storage/{$item->cover_photo->img_url}")); ?>" class="img-fluid" alt="<?php echo e($item->title->$lang); ?>">
                                </a>

                                <div class="product-action">
                                    <ul>
                                        <li><a href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"><i class="fa fa-search  mt-2"></i></a></li>

                                        <li><a data-id="<?php echo e($item->id); ?>" class="addToFavourite" href="javascript:void(0)" title="<?php echo e($langJson->home->favourite); ?>"><i class="fa fa-heart  mt-2"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product-content">
                                <h3 class="title"> <a href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"><?php echo e($item->title->$lang); ?></a></h3>
                                <p class="product-price"><span class="discounted-price"><?php echo e($item->price->$lang); ?> <?php echo e($langJson->home->price); ?></span>
                                </p>
                            </div>
                        </div>
                        <!--  Single Grid product End -->
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </div>
    <!--Product section end-->

<?php $__env->stopSection(); ?>
<?php $__env->startSection("footer"); ?>
    <script>

        $(document).ready(function () {
            $(document).on("change", ".product-count", function () {
                if ($(this).val() <= 0) {
                    $(this).val(1)
                }
            })
            $(document).on("click", ".add-to-basket", function () {
                let count = $(".product-option").length;
                let qty = 0;
                let options = [];
                $(".product-option option:selected").each(function (i, item) {
                    let data = $(this)
                    if (data.val() == 0) {
                        iziToast.error({
                            title: "<?php echo e($langJson->alert->error); ?>",
                            message: data.data("name") + "<?php echo e($langJson->alert->null); ?>",
                            position: "topCenter"
                        });
                    } else {
                        options.push(data.val())
                    }
                })
				
                if (options.length === (count/2)) {
                    qty = $(".product-count").val()
                    $.ajax({
                        "url": "<?php echo e(route("theme.{$langJson->routes->basket_add}")); ?>",
                        "data": {"options": options, "count": qty, "id": <?php echo e($viewData->item->id); ?>},
                        "type": "POST"
                    }).done(function (response) {
                        $(".item_count").text(response.count)
                        $("#cart-render").html(response.data)
                        iziToast.success({
                            title: "<?php echo e($langJson->alert->success); ?>",
                            message: response.alert,
                            position: "topCenter"
                        });
                        $(".mini_cart_wrapper").effect("shake", {
                            distance: 5,
                            times: 2
                        })
                    })
                }
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/mutfakyapim.com.tr/evodia.mutfakyapim.com.tr/resources/views/theme/product/index.blade.php ENDPATH**/ ?>