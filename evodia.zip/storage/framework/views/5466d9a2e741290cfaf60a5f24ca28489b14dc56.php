<?php $__env->startSection("title",$langJson->menu->corporate); ?>
<?php $__env->startSection("header"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <?php $__env->startSection("menuClass","bg-dark"); ?>
<!--breadcrumbs area start-->
<div class="breadcrumbs_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_content">
                    <h3><?php echo e($viewData->item->title->$lang); ?></h3>
                    <ul>
                        <li><a  href="<?php echo e(route("theme.{$langJson->routes->home}")); ?>"><?php echo e($langJson->menu->home); ?></a></li>
                        <li><?php echo e($viewData->item->title->$lang); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!--breadcrumbs area end-->

<!--about section area -->
<section class="about_section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="about_content">
                    <h1><?php echo e($viewData->item->title->$lang); ?></h1>
                        <p><?php echo e($viewData->item->description->$lang); ?></p>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="about_thumb">
                    <img src="<?php echo e(asset("storage/{$viewData->item->img_url->$lang}")); ?>" alt="<?php echo e($viewData->item->title->$lang); ?>">
                </div>
            </div>
        </div>
    </div>
</section>
<!--about section end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\unique\resources\views/theme/corporate/index.blade.php ENDPATH**/ ?>