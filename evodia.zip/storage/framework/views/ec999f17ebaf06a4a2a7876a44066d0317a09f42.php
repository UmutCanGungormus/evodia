<?php $__env->startSection("title",$langJson->menu->corporate); ?>
<?php $__env->startSection("header"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<!-- Page Banner Section Start -->
<div class="page-banner-section section bg-image" data-bg="assets/images/bg/breadcrumb.png">
    <div class="container">
        <div class="row">
            <div class="col">

                <div class="page-banner text-left">
                    <h2><?php echo e($langJson->menu->account); ?></h2>
                    <ul class="page-breadcrumb">
                        <li><a href="index.html"><?php echo e($langJson->menu->home); ?></a></li>
                        <li><?php echo e($langJson->menu->account); ?></li>
                    </ul>
                </div>

            </div>
        </div>
    </div>
</div>
<!-- Page Banner Section End -->

<div class="my-account-section section pt-90 pt-lg-70 pt-md-60 pt-sm-50 pt-xs-45  pb-100 pb-lg-80 pb-md-70 pb-sm-60 pb-xs-50">
    <div class="container">
        <div class="row">

            <div class="col-12">
                <div class="row">
                    <!-- My Account Tab Menu Start -->
                    <div class="col-lg-3 col-12">
                        <div class="myaccount-tab-menu nav" role="tablist">

                            <a href="#account-info" class="active"  data-toggle="tab"><i class="fa fa-user"></i> Hesap Detayları</a>

                            <a href="#orders" data-toggle="tab"><i class="fa fa-cart-arrow-down"></i> Siparişler</a>

                            <a href="#download" data-toggle="tab"><i class="fas fa-tags"></i> İndirim Kuponları</a>

                            <a href="#address-edit" data-toggle="tab"><i class="fa fa-sign-out-alt"></i> Adresler</a>


                            <a href="<?php echo e(route("theme.{$langJson->routes->logout}")); ?>"><i class="fas fa-sign-out-alt"></i> <?php echo e($langJson->home->logout); ?></a>
                        </div>
                    </div>
                    <!-- My Account Tab Menu End -->

                    <!-- My Account Tab Content Start -->
                    <div class="col-lg-9 col-12">
                        <div class="tab-content" id="myaccountContent">

                            <!-- Single Tab Content Start -->
                            <div class="tab-pane fade" id="orders" role="tabpanel">
                                <div class="myaccount-content">
                                    <h3>Orders</h3>

                                    <div class="myaccount-table table-responsive text-center">
                                        <table class="table table-bordered">
                                            <thead class="thead-light">
                                            <tr>
                                                <th>No</th>
                                                <th>Name</th>
                                                <th>Date</th>
                                                <th>Status</th>
                                                <th>Total</th>
                                                <th>Action</th>
                                            </tr>
                                            </thead>

                                            <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td>Mostarizing Oil</td>
                                                <td>Aug 22, 2018</td>
                                                <td>Pending</td>
                                                <td>$45</td>
                                                <td><a href="cart.html" class="btn">View</a></td>
                                            </tr>
                                            <tr>
                                                <td>2</td>
                                                <td>Katopeno Altuni</td>
                                                <td>July 22, 2018</td>
                                                <td>Approved</td>
                                                <td>$100</td>
                                                <td><a href="cart.html" class="btn">View</a></td>
                                            </tr>
                                            <tr>
                                                <td>3</td>
                                                <td>Murikhete Paris</td>
                                                <td>June 12, 2017</td>
                                                <td>On Hold</td>
                                                <td>$99</td>
                                                <td><a href="cart.html" class="btn">View</a></td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- Single Tab Content End -->

                            <!-- Single Tab Content Start -->
                            <div class="tab-pane fade" id="download" role="tabpanel">
                                <div class="myaccount-content">
                                    <h3>Downloads</h3>

                                    <div class="myaccount-table table-responsive text-center">
                                        <table class="table table-bordered">
                                            <thead class="thead-light">
                                            <tr>
                                                <th>Product</th>
                                                <th>Date</th>
                                                <th>Expire</th>
                                                <th>Download</th>
                                            </tr>
                                            </thead>

                                            <tbody>
                                            <tr>
                                                <td>Mostarizing Oil</td>
                                                <td>Aug 22, 2018</td>
                                                <td>Yes</td>
                                                <td><a href="#" class="btn">Download File</a></td>
                                            </tr>
                                            <tr>
                                                <td>Katopeno Altuni</td>
                                                <td>Sep 12, 2018</td>
                                                <td>Never</td>
                                                <td><a href="#" class="btn">Download File</a></td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- Single Tab Content End -->

                            <!-- Single Tab Content Start -->
                            <div class="tab-pane fade" id="address-edit" role="tabpanel">
                                <div class="myaccount-content">
                                    <h3>Billing Address</h3>

                                    <address>
                                        <p><strong>Alex Tuntuni</strong></p>
                                        <p>1355 Market St, Suite 900 <br>
                                            San Francisco, CA 94103</p>
                                        <p>Mobile: (123) 456-7890</p>
                                    </address>

                                    <a href="#" class="btn d-inline-block edit-address-btn"><i class="fa fa-edit"></i>Edit Address</a>
                                </div>
                            </div>
                            <!-- Single Tab Content End -->

                            <!-- Single Tab Content Start -->
                            <div class="tab-pane fade  show active" id="account-info" role="tabpanel">
                                <div class="myaccount-content">
                                    <h3>Hesap Detayları </h3>

                                    <div class="account-details-form">
                                        <form method="POST" action="<?php echo e(route("theme.{$langJson->routes->account}")); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="row">
                                                <div class="col-lg-6 col-12 mb-30">
                                                    <label><?php echo e($langJson->login->full_name); ?></label>
                                                    <input type="text" value="<?php echo e(\Session::get("user")->full_name); ?>" name="full_name">
                                                </div>
                                                <div class="col-lg-6 col-12 mb-30">
                                                    <label><?php echo e($langJson->login->email); ?></label>
                                                    <input type="text" value="<?php echo e(\Session::get("user")->email); ?>" name="email">
                                                </div>
                                                <div class="col-lg-6 col-12 mb-30">
                                                    <label><?php echo e($langJson->login->phone); ?></label>
                                                    <input type="text" value="<?php echo e(\Session::get("user")->phone); ?>" name="phone">
                                                </div>

                                                <div class="col-12 mb-30">
                                                    <h4>Password change</h4>
                                                </div>

                                                <div class="col-lg-6 col-12 mb-30">
                                                    <label><?php echo e($langJson->login->password); ?> <small class="text-danger">(<?php echo e($langJson->account->pass_null); ?>)</small></label>
                                                    <input type="password" name="password">
                                                </div>
                                                <div class="col-lg-6 col-12 mb-30">
                                                    <label><?php echo e($langJson->login->confirm_password); ?> <small class="text-danger">(<?php echo e($langJson->account->pass_null); ?>)</small></label>
                                                    <input type="password" name="password_confirmation">
                                                </div>

                                                <div class="col-12">
                                                    <button type="submit" class="w-100 btn btn-success save-change-btn"><?php echo e($langJson->home->submit); ?></button>
                                                </div>

                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- Single Tab Content End -->
                        </div>
                    </div>
                    <!-- My Account Tab Content End -->
                </div>

            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\evodia\resources\views/theme/account/index.blade.php ENDPATH**/ ?>