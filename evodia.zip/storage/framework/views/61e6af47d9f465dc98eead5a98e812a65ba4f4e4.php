<div class="row shop_wrapper grid_list">
    <?php $__currentLoopData = $viewData->products->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-12">
            <div class="single_product">
                <div class="product_thumb">
                    <a class="primary_img" href="<?php echo e(route("theme.{$langJson->routes->product}",$product->seo_url->$lang)); ?>">
                        <img src="<?php echo e(asset("storage/{$product->cover_photo->img_url}")); ?>" alt=""></a>
                    <?php if(!empty($product->isDisDisDiscount)): ?>
                        <div class="label_product">
                            <span class="label_sale"><?php echo e($langJson->home->discount); ?></span>
                        </div>
                    <?php endif; ?>
                    <div class="action_links">
                        <ul>
                            <li class="quick_button"><a href="<?php echo e(route("theme.{$langJson->routes->product}",$product->seo_url->$lang)); ?>">
                                    <span class="pe-7s-search"></span></a></li>
                            <li class="wishlist"><a href="wishlist.html"><span
                                        class="pe-7s-like"></span></a></li>

                        </ul>
                    </div>
                </div>
                <div class="product_content grid_content">
                    <div class="product_content_inner">
                        <h4 class="product_name"><a
                                href="<?php echo e(route("theme.{$langJson->routes->product}",$product->seo_url->$lang)); ?>"><?php echo e($product->title->$lang); ?></a></h4>
                        <div class="price_box">
                                            <span
                                                class="current_price"><?php echo e($product->price->$lang); ?> <?php echo e($langJson->home->price); ?></span>
                        </div>
                    </div>
                    <div class="add_to_cart">
                        <a href="<?php echo e(route("theme.{$langJson->routes->product}",$product->seo_url->$lang)); ?>"><?php echo e($langJson->home->examine); ?></a>
                    </div>
                </div>
                <div class="product_content list_content">
                    <h4 class="product_name"><a
                            href="<?php echo e(route("theme.{$langJson->routes->product}",$product->seo_url->$lang)); ?>"><?php echo e($product->title->$lang); ?></a></h4>
                    <div class="price_box">
                                        <span
                                            class="current_price"><?php echo e($product->price->$lang); ?> <?php echo e($langJson->home->price); ?></span>
                    </div>

                    <div class="product_desc">
                        <p><?php echo e($product->description->$lang); ?></p>
                    </div>
                    <div class="add_to_cart shop_list_cart">
                        <a href="<?php echo e(route("theme.{$langJson->routes->product}",$product->seo_url->$lang)); ?>"><?php echo e($langJson->home->examine); ?></a>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</div>

<?php /**PATH C:\xampp\htdocs\unique\resources\views/theme/category/order.blade.php ENDPATH**/ ?>