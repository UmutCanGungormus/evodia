<?php $__env->startSection("title",$langJson->menu->home); ?>
<?php $__env->startSection("header"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<!--slider section start-->
<div class="hero-section section position-relative">
    <div class="hero-slider section">
    <?php $__currentLoopData = $viewData->slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!--Hero Item start-->
            <div class="hero-item  bg-image" data-bg="<?php echo e(asset("storage/{$slide->img_url->$lang}")); ?>">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <!--Hero Content start-->
                            <div class="hero-content-2 center">
                                <h2><?php echo e($slide->title->$lang); ?></h2>
                                <a href="<?php echo e((!empty($slide->url->$lang)?$slide->url->$lang:"#")); ?>" class="btn"><?php echo e($langJson->home->examine); ?></a>
                            </div>
                            <!--Hero Content end-->
                        </div>
                    </div>
                </div>
            </div>
            <!--Hero Item end-->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><!--slider section end-->


<!-- Banner section start -->
<div class="banner-section section pt-30">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $viewData->banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <!-- Single Banner Start -->
                    <div class="single-banner-item mb-30">
                        <div class="banner-image">
                            <a href="<?php echo e($item->url->$lang); ?>">
                                <img src="<?php echo e(asset("storage/{$item->img_url->$lang}")); ?>" alt="<?php echo e($item->title->$lang); ?>">
                            </a>
                        </div>
                        <div class="banner-content">
                            <h3 class="title"><?php echo e($item->title->$lang); ?></h3>
                            <a href="<?php echo e($item->url->$lang); ?>"><?php echo e($langJson->home->examine); ?></a>
                        </div>
                    </div>
                    <!-- Single Banner End -->
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</div><!-- Banner section End -->


<!--Product section start-->
<div class="product-section section pt-70 pt-lg-50 pt-md-40 pt-sm-30 pt-xs-20 pb-55 pb-lg-35 pb-md-25 pb-sm-15 pb-xs-5">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="section-title text-center mb-15">
                    <h2><?php echo e($langJson->home->trendProduct); ?></h2>
                </div>
            </div>
        </div>
        <div class="tab-content">
            <div id="home" class="tab-pane fade active show">
                <div class="row">
                    <?php $__currentLoopData = $viewData->discountProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-4 col-sm-6">
                            <!--  Single Grid product Start -->
                            <div class="single-grid-product mb-40">
                                <div class="product-image">
                                    <?php if($item->isDiscount): ?>
                                        <div class="product-label">
                                            <span><?php echo e($langJson->home->discount); ?></span>
                                        </div>
                                    <?php endif; ?>

                                    <a href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>">
                                        <img src="<?php echo e(asset("storage/{$item->cover_photo->img_url}")); ?>" class="img-fluid" alt="<?php echo e($item->title->$lang); ?>">
                                    </a>

                                    <div class="product-action">
                                        <ul>
                                            <li><a href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"><i class="fa fa-search mt-2"></i></a></li>

                                            <li><a data-id="<?php echo e($item->id); ?>" class="addToFavourite" href="javascript:void(0)" title="<?php echo e($langJson->home->favourite); ?>"><i class="fa fa-heart mt-2"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="product-content">
                                    <h3 class="title"> <a href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"><?php echo e($item->title->$lang); ?></a></h3>
                                    <p class="product-price"><span class="discounted-price"><?php echo e($item->price->$lang); ?> <?php echo e($langJson->home->price); ?></span>
                                    </p>
                                </div>
                            </div>
                            <!--  Single Grid product End -->
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>

        </div>


    </div>
</div><!--Product section end-->

<!--Product section start-->
<div class="product-section section pt-70 pt-lg-50 pt-md-40 pt-sm-30 pt-xs-20 pb-55 pb-lg-35 pb-md-25 pb-sm-15 pb-xs-5">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="section-title text-center mb-15">
                    <h2><?php echo e($langJson->home->isComing); ?></h2>
                </div>
            </div>
        </div>
        <div class="tab-content">
            <div id="home" class="tab-pane fade active show">
                <div class="row">
                    <?php $__currentLoopData = $viewData->homeProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-4 col-sm-6">
                            <!--  Single Grid product Start -->
                            <div class="single-grid-product mb-40">
                                <div class="product-image">
                                    <?php if($item->isDiscount): ?>
                                        <div class="product-label">
                                            <span><?php echo e($langJson->home->discount); ?></span>
                                        </div>
                                    <?php endif; ?>

                                    <a href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>">
                                        <img src="<?php echo e(asset("storage/{$item->cover_photo->img_url}")); ?>" class="img-fluid" alt="<?php echo e($item->title->$lang); ?>">
                                    </a>

                                    <div class="product-action">
                                        <ul>
                                            <li><a href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"><i class="fa fa-search  mt-2"></i></a></li>

                                            <li><a data-id="<?php echo e($item->id); ?>" class="addToFavourite" href="javascript:void(0)" title="<?php echo e($langJson->home->favourite); ?>"><i class="fa fa-heart  mt-2"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="product-content">
                                    <h3 class="title"> <a href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"><?php echo e($item->title->$lang); ?></a></h3>
                                    <p class="product-price"><span class="discounted-price"><?php echo e($item->price->$lang); ?> <?php echo e($langJson->home->price); ?></span>
                                    </p>
                                </div>
                            </div>
                            <!--  Single Grid product End -->
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>

        </div>


    </div>
</div><!--Product section end-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\evodia\resources\views/theme/home/index.blade.php ENDPATH**/ ?>