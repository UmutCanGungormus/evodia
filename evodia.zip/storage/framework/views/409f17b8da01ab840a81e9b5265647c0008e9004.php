<?php $__env->startSection("title","panel Ayarlar"); ?>
<?php $__env->startSection("header"); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css"
          integrity="sha512-nMNlpuaDPrqlEls3IX/Q56H36qvBASwb3ipuo3MxeWbsQB1881ox0cRv7UPTgBlriqoynt35KjEwgGUeUXIPnw=="
          crossorigin="anonymous"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <!-- Page body start -->
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <!-- Material tab card start -->
                            <div class="card">
                                <div class="card-header">
                                    <h5> <?php echo e($data->page->title); ?></h5>
                                </div>
                                <div class="card-block">
                                    <!-- Row start -->
                                    <div class="row m-b-30">
                                        <div class="col-12">
                                            <!-- Nav tabs -->
                                            <ul class="nav nav-tabs md-tabs" role="tablist">
                                                <?php $__currentLoopData = $data->settings_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="nav-item">
                                                        <a class="nav-link <?=($key == 0 ? "active" : "")?>"
                                                           data-toggle="tab" href="#<?php echo e($v->languages->code); ?>"
                                                           role="tab">Dil: <?php echo e($v->languages->code); ?></a>
                                                        <div class="slide"></div>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                            <!-- Tab panes -->
                                            <form enctype="multipart/form-data" class="form-material" method="POST"
                                                  action="<?php echo e(route("panel.productCategory.update",$data->item->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <div class="tab-content card-block">
                                                    <?php $__currentLoopData = $data->settings_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $lang=$v->languages->code;
                                                        ?>
                                                        <div class="tab-pane <?=($key == 0 ? "active" : "")?>"
                                                             id="<?php echo e($lang); ?>" role="tabpanel">
                                                            <div class="row">
                                                                <div
                                                                    class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                                                    <div class="form-group form-default">
                                                                        <input type="text"
                                                                               value="<?php echo e($data->item->title->$lang); ?>"
                                                                               name="title[<?php echo e($lang); ?>]"
                                                                               class="form-control">
                                                                        <span class="form-bar"></span>
                                                                        <label class="float-label">Kategori Adı</label>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 ">


                                                                    <div class="form-group row">
                                                                        <label
                                                                            class="col-sm-1 col-form-label">Görsel</label>
                                                                        <div class="col-2">
                                                                            <img
                                                                                src="<?php echo e(asset("storage/{$data->item->img_url->$lang}")); ?>"
                                                                                class="img-fluid">
                                                                        </div>
                                                                        <div class="col-6">
                                                                            <input type="file"
                                                                                   name="img_url[<?php echo e($lang); ?>]"
                                                                                   data-id="img-inputs-<?php echo e($lang); ?>"
                                                                                   id="img-input-<?php echo e($lang); ?>"
                                                                                   class="form-control img-input">
                                                                        </div>
                                                                        <div class="col-3 d-none"
                                                                             id="img-inputs-<?php echo e($lang); ?>">
                                                                            <a href="javascript:void(0)"
                                                                               data-id="img-input-<?php echo e($lang); ?>"
                                                                               class="btn btn-primary input-change">Değiştir</a>
                                                                            <a href="javascript:void(0)"
                                                                               data-id="img-input-<?php echo e($lang); ?>"
                                                                               class="btn btn-danger input-destroy">Kaldır</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                                                    <div class="form-group form-default">
                                                                        <label>Kategori Açıklaması</label>
                                                                        <textarea
                                                                            name="description[<?php echo e($lang); ?>]"
                                                                            class="m-0 tinymce"><?php echo e($data->item->description->$lang); ?></textarea>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="form-group form-default">
                                                                <select name="top_id"
                                                                        class="form-control fill category">
                                                                    <option value="0">Ana Kategori</option>
                                                                    <?php $__currentLoopData = $data->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($category->id!=$data->item->id): ?>
                                                                            <option
                                                                                <?=($data->item->top_id == $category->id ? "selected" : "")?> value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?>  </option>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                                <label class="float-label">Üst Kategori Seç</label>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div
                                                    class="col-12 col-sm-12 col-md-12 col-lg-4 col-xl-4 offset-0 offset-sm-0 offset-md-0 offset-lg-8 offset-xl-8 text-right">
                                                    <input type="submit" class="btn btn-primary rounded" value="Kaydet">
                                                    <a href="<?php echo e(route("panel.settings.index")); ?>"
                                                       class="btn btn-danger rounded">İptal</a>
                                                </div>
                                            </form>

                                        </div>

                                    </div>
                                    <!-- Row end -->
                                </div>
                            </div>
                            <!-- Material tab card end -->
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("footer"); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"
            integrity="sha512-2ImtlRlf2VVmiGZsjm9bEyhjGW4dU7B6TNwh/hx/iSByxNENtj3WVE6o/9Lj4TJeVXPi4bnOIMXFIJJAeufa0A=="
            crossorigin="anonymous"></script>
    <script>
        $(document).ready(function () {
            $('.category').select2({
                language: "tr"
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\evodia\resources\views/panel/productCategory/update/index.blade.php ENDPATH**/ ?>
