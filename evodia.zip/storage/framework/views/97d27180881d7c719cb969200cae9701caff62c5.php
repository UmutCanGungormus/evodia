<?php $__env->startSection("title",$langJson->menu->products); ?>
<?php $__env->startSection("header"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<?php $__env->startSection("menuClass","bg-dark"); ?>
<!--breadcrumbs area start-->
<div class="breadcrumbs_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_content">
                    <h3>Sepet</h3>
                    <ul>
                        <li><a href="index.html">Anasayfa</a></li>
                        <li>Alışveriş Sepeti</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!--breadcrumbs area end-->

<!--shopping cart area start -->
<div class="shopping_cart_area">
    <div class="container">
        <form action="#">
            <div class="row">
                <div class="col-12">
                    <div class="table_desc">
                        <div class="cart_page table-responsive">
                            <table>
                                <thead>
                                <tr>
                                    <th class="product_remove">Sil</th>
                                    <th class="product_thumb">Resim</th>
                                    <th class="product_name">Ürün</th>
                                    <th class="product-price">Fiyat</th>
                                    <th class="product_quantity">Adet</th>
                                    <th class="product_total">Toplam</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="product_remove"><a href="javascript:void(0)" class="delete-cart-item" data-id="<?php echo e($item->id); ?>"><i
                                                    class="fa fa-trash "></i></a></td>
                                        <td class="product_thumb"><a href="#"><img
                                                    src="<?php echo e(asset("storage/{$item->associatedModel->cover_photo->img_url}")); ?>"
                                                    alt=""></a></td>
                                        <td class="product_name"><a href="<?php echo e(route("theme.{$langJson->routes->product}",$item->associatedModel->seo_url->$lang)); ?>"><?php echo e($item->name->$lang); ?></a></td>
                                        <td class="product-price"><?php echo e($item->price." ".$langJson->home->price); ?></td>
                                        <td class="product_quantity"><label>Adet</label> <input min="1" max="100"
                                                                                                value="<?php echo e($item->quantity); ?>"
                                                                                                type="number"></td>
                                        <td class="product_total"><?php echo e($item->price*$item->quantity." ".$langJson->home->price); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!--coupon code area start-->
            <div class="coupon_area">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="coupon_code left">
                            <h3>Kupon</h3>
                            <div class="coupon_inner">
                                <p>Sahip Olduğunuz Kuponlarınızı Sepetinizde Kullanabilirsiniz.</p>
                                <input placeholder="Kuponu Kodu" type="text">
                                <button type="submit">Kuponu Uygula</button>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="coupon_code right">
                            <h3>Sepet Toplamı</h3>
                            <div class="coupon_inner">
                                <div class="cart_subtotal">
                                    <p>Ara Toplam</p>
                                    <p class="cart_amount"><?php echo e(\Cart::getTotal() ." ". $langJson->home->price); ?></p>
                                </div>
                                <div class="cart_subtotal d-none">
                                    <p>Kargo</p>
                                    <p class="cart_amount"><span>Sabit Fiyat:</span> £255.00</p>
                                </div>

                                <div class="cart_subtotal">
                                    <p>Toplam</p>
                                    <p class="cart_amount"><?php echo e(\Cart::getTotal() ." ". $langJson->home->price); ?></p>
                                </div>
                                <div class="checkout_btn">
                                    <a href="#">Alışverişi Tamamla</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--coupon code area end-->
        </form>
    </div>
</div>
<!--shopping cart area end -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection("footer"); ?>
    <script>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\unique\resources\views/theme/basket/index.blade.php ENDPATH**/ ?>