<?php $__env->startSection("title",$langJson->menu->products); ?>
<?php $__env->startSection("header"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<?php $__env->startSection("menuClass","bg-dark"); ?>
<!--breadcrumbs area start-->
<div class="breadcrumbs_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_content">
                    <h3><?php echo e($viewData->item->title->$lang); ?></h3>
                    <ul>
                        <li><a href="index.html"><?php echo e($langJson->menu->home); ?></a></li>
                        <li><?php echo e($viewData->item->title->$lang); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!--breadcrumbs area end-->

<!--product details start-->
<div class="product_details mb-80">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-md-5">
                <div class="product-details-tab">
                    <div id="img-1" class="zoomWrapper single-zoom">
                        <a href="#">
                            <img id="zoom1" src="<?php echo e(asset("storage/{$viewData->products->photos->{0}->img_url}")); ?>"
                                 data-zoom-image="<?php echo e(asset("storage/{$viewData->products->photos->{0}->img_url}")); ?>"
                                 alt="big-1">
                        </a>
                    </div>
                    <div class="single-zoom-thumb">
                        <ul class="s-tab-zoom owl-carousel single-product-active" id="gallery_01">
                            <?php $__currentLoopData = $viewData->products->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="#" class="elevatezoom-gallery <?php echo e(($key==0?"active":"")); ?>" data-update=""
                                       data-image="<?php echo e(asset("storage/{$photo->img_url}")); ?>"
                                       data-zoom-image="<?php echo e(asset("storage/{$photo->img_url}")); ?>">
                                        <img src="<?php echo e(asset("storage/{$photo->img_url}")); ?>" alt="zo-th-1"/>
                                    </a>

                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-7 col-md-7">
                <div class="product_d_right">
                    <form action="#">
                        <div class="productd_title_nav">
                            <h1>
                                <a href="<?php echo e(route("theme.{$langJson->routes->product}",$viewData->item->seo_url->$lang)); ?>"><?php echo e($viewData->item->title->$lang); ?></a>
                            </h1>

                        </div>

                        <div class="price_box">
                            <span
                                class="current_price"><?php echo e(number_format($viewData->item->price->$lang,"2")); ?> <?php echo e($langJson->home->price); ?></span>
                        </div>
                        <div class="product_desc">
                            <p><?php echo e(Str::words($viewData->item->description->$lang,"3","...")); ?></p>
                        </div>
                        <div class="product_variant color">
                            <?php if(!empty($viewData->products->option_categories)): ?>
                                <h3><?php echo e($langJson->products->options); ?></h3>
                                <?php $__currentLoopData = $viewData->products->option_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="input-group mb-3">
                                        <label class="input-group-text"
                                               for="select-<?php echo e($key); ?>"><?php echo e($option->title->$lang); ?></label>
                                        <select class="form-select product-option" id="select-<?php echo e($key); ?>">
                                            <option data-name="<?php echo e($option->title->$lang); ?>"
                                                    value="0"><?php echo e($langJson->products->select); ?></option>
                                            <?php $__currentLoopData = $viewData->products->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($opt->category_id==$option->id): ?>
                                                <option
                                                    value="<?php echo e($opt->id); ?>"
                                                    data-name="<?php echo e($option->title->$lang); ?>" <?php echo e(($opt->stock->$lang<=0?"disabled":"")); ?>><?php echo e($opt->title->$lang); ?> </option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <div class="product_variant quantity">
                            <label><?php echo e($langJson->products->count); ?></label>
                            <input class="product-count" min="1" max="100" value="1" type="number">
                            <button class="button add-to-basket"
                                    type="button"><?php echo e($langJson->products->add_basket); ?></button>

                        </div>
                        <div class=" product_d_action">
                            <ul>
                                <li><a href="#" title="Add to wishlist">+ <i class="fas fa-heart fa-2x "></i></a></li>
                            </ul>
                        </div>
                        <div class="product_meta">
                            <span><?php echo e($langJson->menu->category); ?>:
                            <?php $__currentLoopData = $viewData->products->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="ml-1"
                                       href="<?php echo e(route("theme.{$langJson->routes->category}",$category->seo_url->$lang)); ?>"><?php echo e($category->title->$lang); ?> <?php echo e(($key%2==0 ?"/":"")); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </span>
                        </div>

                    </form>


                </div>
            </div>
        </div>
    </div>
</div>
<!--product details end-->

<!--product info start-->
<div class="product_d_info mb-77">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="product_d_inner">
                    <div class="product_info_button">
                        <ul class="nav" role="tablist">
                            <li>
                                <a class="active" data-toggle="tab" href="#info" role="tab" aria-controls="info"
                                   aria-selected="false"><?php echo e($langJson->products->description); ?></a>
                            </li>
                            <li>
                                <a data-toggle="tab" href="#sheet" role="tab" aria-controls="sheet"
                                   aria-selected="false"><?php echo e($langJson->products->features); ?></a>
                            </li>

                        </ul>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="info" role="tabpanel">
                            <div class="product_info_content">
                                <p><?php echo e($viewData->item->description->$lang); ?></p>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="sheet" role="tabpanel">
                            -
                            <div class="product_info_content">
                                <p><?php echo e($viewData->item->features->$lang); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--product info end-->
<!--product area start-->
<div class="product_area  mb-95">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section_title product_shop_title">
                    <h2><?php echo e($langJson->home->trendProduct); ?></h2>
                </div>

            </div>
        </div>
        <div class="row">
            <div class="product_carousel product_column5 owl-carousel">
                <?php $__currentLoopData = $viewData->homeProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3">
                        <div class="product_items">
                            <article class="single_product">
                                <figure>
                                    <div class="product_thumb">
                                        <a class="primary_img"
                                           href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"><img
                                                src="<?php echo e(asset("storage/{$item->cover_photo->img_url}")); ?>"
                                                alt="<?php echo e($item->title->$lang); ?>"></a>
                                        <?php if($item->isDiscount): ?>
                                            <div class="label_product">
                                                <span class="label_sale"><?php echo e($langJson->home->discount); ?></span>
                                            </div>
                                        <?php endif; ?>
                                        <div class="action_links">
                                            <ul>
                                                <li class="quick_button"><a
                                                        href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"
                                                        title="<?php echo e($langJson->home->examine); ?>"> <span
                                                            class="pe-7s-search"></span></a></li>
                                                <li class="wishlist"><a data-id="<?php echo e($item->id); ?>"
                                                                        class="addToFavourite" href="javascript:void(0)"
                                                                        title="<?php echo e($langJson->home->favourite); ?>"><span
                                                            class="pe-7s-like"></span></a>
                                                </li>

                                            </ul>
                                        </div>
                                    </div>
                                    <figcaption class="product_content">
                                        <div class="product_content_inner">
                                            <?php if(!empty($item->category)): ?>
                                                <h6 class="product_name">
                                                    <?php $__currentLoopData = $item->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <a href=""><?php echo e($category->title->$lang); ?> <?php echo e((count((array)$item->category)-1!=$cat_key?"/":"")); ?></a>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </h6>
                                            <?php endif; ?>
                                            <h4 class="product_name"><a
                                                    href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"><?php echo e($item->title->$lang); ?></a>
                                            </h4>
                                            <div class="price_box">
                                                    <span
                                                        class="current_price"><?php echo e($item->price->$lang); ?> <?php echo e($langJson->home->price); ?></span>
                                            </div>
                                        </div>
                                        <div class="add_to_cart">
                                            <a href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"><?php echo e($langJson->home->examine); ?></a>
                                        </div>
                                    </figcaption>
                                </figure>
                            </article>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<!--product area end-->
<!--product area start-->
<div class="product_area  mb-95">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section_title product_shop_title">
                    <h2><?php echo e($langJson->home->isComing); ?></h2>
                </div>

            </div>
        </div>
        <div class="row">
            <div class="product_carousel product_column5 owl-carousel">
                <?php $__currentLoopData = $viewData->discountProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3">
                        <div class="product_items">
                            <article class="single_product">
                                <figure>
                                    <div class="product_thumb">
                                        <a class="primary_img"
                                           href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"><img
                                                src="<?php echo e(asset("storage/{$item->cover_photo->img_url}")); ?>"
                                                alt="<?php echo e($item->title->$lang); ?>"></a>
                                        <?php if($item->isDiscount): ?>
                                            <div class="label_product">
                                                <span class="label_sale"><?php echo e($langJson->home->discount); ?></span>
                                            </div>
                                        <?php endif; ?>
                                        <div class="action_links">
                                            <ul>
                                                <li class="quick_button"><a
                                                        href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"
                                                        title="<?php echo e($langJson->home->examine); ?>"> <span
                                                            class="pe-7s-search"></span></a></li>
                                                <li class="wishlist"><a data-id="<?php echo e($item->id); ?>"
                                                                        class="addToFavourite" href="javascript:void(0)"
                                                                        title="<?php echo e($langJson->home->favourite); ?>"><span
                                                            class="pe-7s-like"></span></a>
                                                </li>

                                            </ul>
                                        </div>
                                    </div>
                                    <figcaption class="product_content">
                                        <div class="product_content_inner">
                                            <?php if(!empty($item->category)): ?>
                                                <h6 class="product_name">
                                                    <?php $__currentLoopData = $item->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <a href=""><?php echo e($category->title->$lang); ?> <?php echo e((count((array)$item->category)-1!=$cat_key?"/":"")); ?></a>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </h6>
                                            <?php endif; ?>
                                            <h4 class="product_name"><a
                                                    href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"><?php echo e($item->title->$lang); ?></a>
                                            </h4>
                                            <div class="price_box">
                                                    <span
                                                        class="current_price"><?php echo e($item->price->$lang); ?> <?php echo e($langJson->home->price); ?></span>
                                            </div>
                                        </div>
                                        <div class="add_to_cart">
                                            <a href="<?php echo e(route("theme.{$langJson->routes->product}",$item->seo_url->$lang)); ?>"><?php echo e($langJson->home->examine); ?></a>
                                        </div>
                                    </figcaption>
                                </figure>
                            </article>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<!--product area end-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection("footer"); ?>
    <script>

        $(document).ready(function () {
            $(document).on("change", ".product-count", function () {
                if ($(this).val() <= 0) {
                    $(this).val(1)
                }
            })
            $(document).on("click", ".add-to-basket", function () {
                let count = $(".product-option").length;
                let qty = 0;
                let options = [];
                $(".product-option option:selected").each(function (i, item) {
                    let data = $(this)
                    if (data.val() == 0) {
                        iziToast.error({
                            title: "<?php echo e($langJson->alert->error); ?>",
                            message: data.data("name") + "<?php echo e($langJson->alert->null); ?>",
                            position: "topCenter"
                        });
                    } else {
                        options.push(data.val())
                    }
                })
                if (options.length == count) {
                    qty = $(".product-count").val()
                    $.ajax({
                        "url": "<?php echo e(route("theme.{$langJson->routes->basket_add}")); ?>",
                        "data": {"options": options, "count": qty, "id": <?php echo e($viewData->item->id); ?>},
                        "type": "POST"
                    }).done(function (response) {
                        $(".item_count").text(response.count)
                        $("#cart-render").html(response.data)
                        iziToast.success({
                            title: "<?php echo e($langJson->alert->success); ?>",
                            message: response.alert,
                            position: "topCenter"
                        });
                        $(".mini_cart_wrapper").effect("shake",{
                            distance:5,
                            times:2
                        })
                    })
                }
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\unique\resources\views/theme/product/index.blade.php ENDPATH**/ ?>