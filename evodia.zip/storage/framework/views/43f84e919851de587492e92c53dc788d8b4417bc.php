<?php $__env->startSection("title",$langJson->menu->corporate); ?>
<?php $__env->startSection("header"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<?php $__env->startSection("menuClass","bg-dark"); ?>
<!--breadcrumbs area start-->
<div class="breadcrumbs_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_content">
                    <h3><?php echo e($langJson->menu->account); ?></h3>
                    <ul>
                        <li><a href="index.html"><?php echo e($langJson->menu->home); ?></a></li>
                        <li><?php echo e($langJson->menu->account); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!--breadcrumbs area end-->

<!-- my account start  -->
<section class="main_content_area">
    <div class="container">
        <div class="account_dashboard">
            <div class="row">
                <div class="col-sm-12 col-md-3 col-lg-3">
                    <!-- Nav tabs -->
                    <div class="dashboard_tab_button">
                        <ul role="tablist" class="nav flex-column dashboard-list">
                            <li><a href="#account-details" data-toggle="tab" class="nav-link active">Hesap Detayları</a></li>
                            <li> <a href="#orders" data-toggle="tab" class="nav-link">Siparişler</a></li>
                            <li><a href="#downloads" data-toggle="tab" class="nav-link">İndirmeler</a></li>
                            <li><a href="#address" data-toggle="tab" class="nav-link">Adresler</a></li>
                            <li><a href="<?php echo e(route("theme.{$langJson->routes->logout}")); ?>" class="nav-link">Çıkış Yap</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-12 col-md-9 col-lg-9">
                    <!-- Tab panes -->
                    <div class="tab-content ">
                        <div class="tab-pane fade show active" id="account-details">
                            <h3>Hesap Detayları </h3>
                            <div class="login">
                                <div class="login_form_container">
                                    <div class="account_login_form">
                                        <form method="POST" action="<?php echo e(route("theme.{$langJson->routes->account}")); ?>">
                                            <?php echo csrf_field(); ?>
                                            <label><?php echo e($langJson->login->full_name); ?></label>
                                            <input type="text" value="<?php echo e(\Session::get("user")->full_name); ?>" name="full_name">
                                            <label><?php echo e($langJson->login->email); ?></label>
                                            <input type="text" value="<?php echo e(\Session::get("user")->email); ?>" name="email">
                                            <label><?php echo e($langJson->login->phone); ?></label>
                                            <input type="text" value="<?php echo e(\Session::get("user")->phone); ?>" name="phone">
                                            <label><?php echo e($langJson->login->password); ?> <small class="text-danger">(<?php echo e($langJson->account->pass_null); ?>)</small></label>
                                            <input type="password" name="password">
                                            <label><?php echo e($langJson->login->confirm_password); ?> <small class="text-danger">(<?php echo e($langJson->account->pass_null); ?>)</small></label>
                                            <input type="password" name="password_confirmation">
                                            <div class="">
                                                <button type="submit" class="w-100 btn btn-success"><?php echo e($langJson->home->submit); ?></button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="orders">
                            <h3>Siparişler</h3>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th>Sipariş</th>
                                        <th>Tarih</th>
                                        <th>Durum</th>
                                        <th>Toplam</th>
                                        <th>İşlemler</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>10 Mayıs, 2018</td>
                                        <td><span class="success">Tamamlandı</span></td>
                                        <td>₺25.00 </td>
                                        <td><a href="cart.html" class="view">Görüntüle</a></td>
                                    </tr>
                                    <tr>
                                        <td>1</td>
                                        <td>10 Mayıs, 2018</td>
                                        <td><span class="success">Tamamlandı</span></td>
                                        <td>₺25.00 </td>
                                        <td><a href="cart.html" class="view">Görüntüle</a></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="downloads">
                            <h3>İndirmeler</h3>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th>Ürün</th>
                                        <th>İndirmeler</th>
                                        <th>Dolum Zamanı</th>
                                        <th>İndir</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>Ürün Adı</td>
                                        <td>10 Mayıs, 2018</td>
                                        <td><span class="danger">Doldu</span></td>
                                        <td><a href="#" class="view">İndirmek İçin Buraya Tıklayın</a></td>
                                    </tr>
                                    <tr>
                                        <td>Ürün Adı</td>
                                        <td>10 Mayıs, 2018</td>
                                        <td><span class="danger">Doldu</span></td>
                                        <td><a href="#" class="view">İndirmek İçin Buraya Tıklayın</a></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane" id="address">
                            <p>Adres Açıklama</p>
                            <h4 class="billing-address">Teslimat ve Fatura Adresi</h4>
                            <a href="#" class="view">Düzenle</a>
                            <p><strong>Test Kullanıcı</strong></p>
                            <address>
                                Test Adres
                            </address>
                            <p>İzmir Türkiye</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- my account end   -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\unique\resources\views/theme/account/index.blade.php ENDPATH**/ ?>