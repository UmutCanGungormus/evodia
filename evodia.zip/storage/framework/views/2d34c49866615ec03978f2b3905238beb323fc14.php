<div class="container-fluid">
    <form action="<?php echo e(route("panel.galleryContent.update",$data->item->id)); ?>" method="POST" id="content-form" class="form-material">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                <div class="form-group form-default">
                    <input type="text" value="<?php echo e($data->item->title); ?>" name="title"
                           class="form-control">
                    <span class="form-bar"></span>
                    <label class="float-label">Başlık</label>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                <div class="form-group ">
                    <label>İçerik Bilgisi</label>
                    <textarea name="description" class="m-0 tinymce"><?php echo e($data->item->description); ?></textarea>
                </div>
            </div>
            <div class="col-12">
                <button class="btn btn-success w-100" id="content-submit" data-url="<?php echo e(route("panel.galleryContent.update",$data->item->id)); ?>" type="button">Gönder</button>
            </div>
        </div>
    </form>

</div>
</div>
<?php /**PATH C:\xampp\htdocs\evodia\resources\views/panel/galleryContent/update/render.blade.php ENDPATH**/ ?>