
<div class="header-cart">
    <ul class="cart-items">
        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="single-cart-item" data-id="<?php echo e($cartItem->id); ?>">
                <div class="cart-img">
                    <a href="<?php echo e(route("theme.{$langJson->routes->product}",$cartItem->associatedModel->seo_url->$lang)); ?>"><img src="<?php echo e(asset("storage/{$cartItem->associatedModel->cover_photo->img_url}")); ?>" alt=""></a>
                </div>
                <div class="cart-content">
                    <h5 class="product-name">
                        <a href="<?php echo e(route("theme.{$langJson->routes->product}",$cartItem->associatedModel->seo_url->$lang)); ?>"><?php echo e($cartItem->name->$lang); ?></a>
                    </h5>
                    <span class="product-quantity"><?php echo e($cartItem->quantity); ?> ×</span>
                    <span class="product-price"><?php echo e($cartItem->associatedModel->price->$lang." ".$langJson->home->price); ?></span>
                </div>
                <div class="cart-item-remove">
                    <a href="javascript:void(0)"><i class="fa fa-trash delete-cart-item" data-id="<?php echo e($cartItem->id); ?>"></i></a>
                </div>
            </li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <div class="cart-total">
        <div class="cart_total">
            <h5><?php echo e($langJson->home->sub_total); ?>: <?php echo e(\Cart::getSubTotal()." ".$langJson->home->price); ?></h5>
        </div>
        <div class="cart_total mt-10">
            <h5><?php echo e($langJson->home->total); ?>: <?php echo e(\Cart::getTotal()." ".$langJson->home->price); ?></h5>
        </div>
    </div>
    <div class="cart-btn">
        <a href="<?php echo e(route("theme.{$langJson->routes->basket}")); ?>"><i class="fa fa-shopping-cart"></i> <?php echo e($langJson->home->basket_go); ?>

        </a>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\evodia\resources\views/theme/basket/render.blade.php ENDPATH**/ ?>