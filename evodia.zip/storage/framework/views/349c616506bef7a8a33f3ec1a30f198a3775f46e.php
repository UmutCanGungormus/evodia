<?php $__env->startSection("title","panel Anasayfa"); ?>
<?php $__env->startSection("content"); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/mutfakyapim.com.tr/evodia.mutfakyapim.com.tr/resources/views/panel/dashboard/index.blade.php ENDPATH**/ ?>