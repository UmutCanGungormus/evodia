<!doctype html>
<html class="no-js" lang="tr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>UNIQUE MODE | <?php echo $__env->yieldContent("title"); ?> </title>
    <meta name="description" content="UNIQUE MODE">
    <meta name="viewport"
          content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- CSS
    ========================= -->
    <!--bootstrap min css-->
    <link rel="stylesheet" href="<?php echo e(asset("theme/assets/css/bootstrap.min.css")); ?>">
    <!--owl carousel min css-->
    <link rel="stylesheet" href="<?php echo e(asset("theme/assets/css/owl.carousel.min.css")); ?>">
    <!--slick min css-->
    <link rel="stylesheet" href="<?php echo e(asset("theme/assets/css/slick.css")); ?>">
    <!--magnific popup min css-->
    <link rel="stylesheet" href="<?php echo e(asset("theme/assets/css/magnific-popup.css")); ?>">
    <!--font awesome css-->
    <link rel="stylesheet" href="<?php echo e(asset("theme/assets/css/font.awesome.css")); ?>">
    <!--ionicons css-->
    <link rel="stylesheet" href="<?php echo e(asset("theme/assets/css/ionicons.min.css")); ?>">
    <!--7 stroke icons css-->
    <link rel="stylesheet" href="<?php echo e(asset("theme/assets/css/pe-icon-7-stroke.css")); ?>">
    <!--animate css-->
    <link rel="stylesheet" href="<?php echo e(asset("theme/assets/css/animate.css")); ?>">
    <!--jquery ui min css-->
    <link rel="stylesheet" href="<?php echo e(asset("theme/assets/css/jquery-ui.min.css")); ?>">
    <!--plugins css-->
    <link rel="stylesheet" href="<?php echo e(asset("theme/assets/css/plugins.css")); ?>">
    <!--iziToast-->
    <link rel="stylesheet" href="<?php echo e(asset("theme/assets/css/iziToast.css")); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset("theme/assets/css/style.css")); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.5.0/css/flag-icon.min.css"/>

    <!--modernizr min js here-->
    <script src="<?php echo e(asset("theme/assets/js/vendor/modernizr-3.7.1.min.js")); ?>"></script>
    <script>let base_url = "<?php echo e(asset("theme/assets")); ?>" </script>
    <script>let ajax_url = "<?php echo e(url("/")); ?>" </script>

</head>

<body>


<!--header area start-->
<header>
    <div class="main_header <?php echo $__env->yieldContent("menuClass"); ?> sticky-header">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-12">
                    <div class="header2_container">
                        <!--offcanvas menu area start-->
                        <div class="offcanvas_menu offcanvas_two">
                            <div class="canvas_open">
                                <a href="javascript:void(0)"><i class="ion-navicon-round"></i></a>
                            </div>
                            <div class="offcanvas_menu_wrapper">
                                <div class="canvas_close">
                                    <a href="javascript:void(0)"><i class="ion-android-close"></i></a>
                                </div>

                                <div id="menu" class="text-left ">
                                    <ul class="offcanvas_main_menu">
                                        <li class="menu-item-has-children">
                                            <a href="<?php echo e(route("theme.{$langJson->routes->home}")); ?>"><?php echo e($langJson->menu->home); ?></a>
                                        </li>
                                        <?php echo $viewData->categories; ?>

                                        <li class="menu-item-has-children">
                                            <a href="#"><?php echo e($langJson->menu->corporate); ?></a>
                                            <ul class="sub-menu">

                                                <?php $__currentLoopData = $viewData->corporates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $corporate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <a href="<?php echo e(route("theme.{$langJson->routes->corporate}",$corporate->seo_url->$lang)); ?>"><?php echo e($corporate->title->$lang); ?></a>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>

                                        </li>

                                        <li class="menu-item-has-children">
                                            <a href="<?php echo e(route("theme.{$langJson->routes->contact}")); ?>"><?php echo e($langJson->menu->contact); ?></a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="offcanvas_footer">
                                    <span><a href="#"><i class="fas fa-envelope"></i> <?php echo e($thisSetting->email); ?></a></span>
                                </div>
                                <div class="dropdown d-inline-block d-inline-block d-inline-block d-lg-none d-xl-none py-auto my-auto  mr-3 rounded-0">
                                    <a class="rounded-0 btn-sm btn btn-secondary dropdown-toggle bg-transparent border-a"
                                       href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown"
                                       aria-haspopup="true" aria-expanded="false">
                                    <span
                                        class="flex-shrink-1 mr-1 align-middle my-auto py-auto flag-icon flag-icon-<?php echo e(($lang=="en"?"us":$lang)); ?>"></span>
                                        <span
                                            class='flex-grow-1 sticky-dark-text align-middle my-auto py-auto'><?php echo e(strtoupper($lang)); ?></span>
                                    </a>

                                    <div class="dropdown-menu rounded-0" aria-labelledby="dropdownMenuLink">
                                        <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $url=\App\Helpers\Helpers::thisPageUrl($setting->language,$langJson,$page);
                                                $parameterLang=$setting->language;
                                            ?>
                                            <a class="dropdown-item"
                                               href="<?php echo e((!empty($parameter)?route("theme.{$url}",$parameter->$parameterLang):route("theme.{$url}"))); ?>">
                                            <span
                                                class="flex-shrink-1 mr-1 align-middle my-auto py-auto flag-icon  flag-icon-<?php echo e(($setting->language=="en"?"us":$setting->language)); ?>"></span>
                                                <span
                                                    class='flex-grow-1 align-middle  my-auto py-auto'><?php echo e(strtoupper($setting->language)); ?></span>
                                            </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--offcanvas menu area end-->
                        <div class="header2_left">
                            <div class="logo logo2">
                                <a href="<?php echo e(route("theme.{$langJson->routes->home}")); ?>"><img class="ml-3"
                                                                                            src="<?php echo e(asset("storage/{$thisSetting->logo}")); ?>"
                                                                                            style="filter: drop-shadow(1px 1px 1px black);"
                                                                                            alt="<?php echo e($thisSetting->company_name); ?>"></a>
                            </div>
                            <div class="logo logo2_sticky">
                                <a href="<?php echo e(route("theme.{$langJson->routes->home}")); ?>"><img class="ml-3 dark-logo"
                                                                                            src="<?php echo e(asset("storage/{$thisSetting->logo}")); ?>"
                                                                                            alt="<?php echo e($thisSetting->company_name); ?>"></a>
                            </div>

                        </div>
                        <div class="header_account_area py-auto my-auto">
                            <div class="dropdown d-none d-sm-none d-md-none d-lg-inline-block d-xl-inline-block py-auto my-auto  mr-3 rounded-0">
                                <a class="rounded-0 btn-sm btn btn-secondary dropdown-toggle bg-transparent border-a"
                                   href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown"
                                   aria-haspopup="true" aria-expanded="false">
                                    <span
                                        class="flex-shrink-1 mr-1 align-middle my-auto py-auto flag-icon flag-icon-<?php echo e(($lang=="en"?"us":$lang)); ?>"></span>
                                    <span
                                        class='flex-grow-1 sticky-dark-text align-middle my-auto py-auto'><?php echo e(strtoupper($lang)); ?></span>
                                </a>

                                <div class="dropdown-menu rounded-0" aria-labelledby="dropdownMenuLink">
                                    <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $url=\App\Helpers\Helpers::thisPageUrl($setting->language,$langJson,$page);
                                            $parameterLang=$setting->language;
                                        ?>
                                        <a class="dropdown-item"
                                           href="<?php echo e((!empty($parameter)?route("theme.{$url}",$parameter->$parameterLang):route("theme.{$url}"))); ?>">
                                            <span
                                                class="flex-shrink-1 mr-1 align-middle my-auto py-auto flag-icon flag-icon-<?php echo e(($setting->language=="en"?"us":$setting->language)); ?>"></span>
                                            <span
                                                class='flex-grow-1 align-middle my-auto py-auto'><?php echo e(strtoupper($setting->language)); ?></span>
                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                            <div class="header_account_list search_list py-auto my-auto">
                                <a href="javascript:void(0)"><span class="pe-7s-search"></span></a>
                                <div class="dropdown_search">
                                    <form action="<?php echo e(route("theme.{$langJson->routes->search}")); ?>" method="GET">
                                        <input name="search" placeholder="<?php echo e($langJson->header->search_placeholder); ?>"
                                               type="text">
                                        <button type="submit"><span class="pe-7s-search"></span></button>
                                    </form>
                                </div>
                            </div>
                            <div class="header_account_list  mini_cart_wrapper py-auto my-auto">
                                <a href="javascript:void(0)"><span class="pe-7s-shopbag"></span>
                                    <span class="item_count"><?php echo e($cart->count()); ?></span>
                                </a>

                            </div>
                            <div class="language_currency header_account_list py-auto my-auto">
                                <a href="#"> <span class="pe-7s-user"></span></a>
                                <ul class="dropdown_currency">
                                    <?php if(\Session::has('user')): ?>
                                        <li><a href="<?php echo e(route("theme.{$langJson->routes->account}")); ?>"><i class="fas fa-user-circle"></i> <?php echo e($langJson->home->account); ?></a></li>
                                        <li><a href="<?php echo e(route("theme.{$langJson->routes->logout}")); ?>"><i class="fas fa-sign-out-alt"></i> <?php echo e($langJson->home->logout); ?></a></li>
                                    <?php else: ?>
                                        <li><a href="<?php echo e(route("theme.{$langJson->routes->login}")); ?>"><i class="fas fa-user"></i> <?php echo e($langJson->login->login); ?></a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--mini cart-->
    <div id="cart-render">
        <div class="mini_cart">
            <div class="cart_gallery">
                <div class="cart_close">
                    <div class="cart_text">
                        <h3><?php echo e($langJson->menu->basket); ?></h3>
                    </div>
                    <div class="mini_cart_close">
                        <a href="javascript:void(0)"><i class="ion-android-close"></i></a>
                    </div>
                </div>
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="cart_item">
                        <div class="cart_img">
                            <a href="<?php echo e(route("theme.{$langJson->routes->product}",$cartItem->associatedModel->seo_url->$lang)); ?>"><img
                                    src="<?php echo e(asset("storage/{$cartItem->associatedModel->cover_photo->img_url}")); ?>"
                                    alt=""></a>
                        </div>
                        <div class="cart_info">
                            <a href="#"><?php echo e($cartItem->name->$lang); ?></a>
                            <p><?php echo e($cartItem->quantity); ?> x
                                <span> <?php echo e($cartItem->associatedModel->price->$lang." ".$langJson->home->price); ?></span>
                            </p>
                        </div>
                        <div class="cart_remove">
                            <a class="delete-cart-item" data-id="<?php echo e($cartItem->id); ?>" href="javascript:void(0)"><i
                                    class="ion-ios-close-outline"></i></a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <div class="mini_cart_table_div bg-light">
                <div class="mini_cart_table">
                    <div class="cart_table_border">
                        <div class="cart_total">
                            <span><?php echo e($langJson->home->sub_total); ?>:</span>
                            <span class="price"><?php echo e(\Cart::getSubTotal()." ".$langJson->home->price); ?></span>
                        </div>
                        <div class="cart_total mt-10">
                            <span><?php echo e($langJson->home->total); ?>:</span>
                            <span class="price"><?php echo e(\Cart::getTotal()." ".$langJson->home->price); ?></span>
                        </div>
                    </div>
                </div>
                <div class="mini_cart_footer">
                    <div class="cart_button">
                        <a href="<?php echo e(route("theme.{$langJson->routes->basket}")); ?>"><i class="fa fa-shopping-cart"></i> <?php echo e($langJson->home->basket_go); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--mini cart end-->
</header>
<?php echo $__env->yieldContent("content"); ?>


<!--shipping area start-->
<div class="shipping_area">
    <div class="container">
        <div class="shipping_container">
            <div class="row">
                <div class="col-lg-4 col-xl-4 col-md-4 col-12">
                    <div class="single_shipping">
                        <div class="shipping_icone">
                            <img src="<?php echo e(asset("theme/assets/img/about/shipping1.png")); ?>" alt="">
                        </div>
                        <div class="shipping_content">
                            <h3><?php echo e($langJson->footer->cargo); ?></h3>
                            <p><?php echo e($langJson->footer->free_shipping); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-xl-4 col-md-4 col-12">
                    <div class="single_shipping">
                        <div class="shipping_icone">
                            <img src="<?php echo e(asset("theme/assets/img/about/shipping2.png")); ?>" alt="">
                        </div>
                        <div class="shipping_content">
                            <h3><?php echo e($langJson->footer->support); ?></h3>
                            <p><?php echo e($langJson->footer->free_text); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-xl-4 col-md-4 col-12">
                    <div class="single_shipping">
                        <div class="shipping_icone">
                            <img src="<?php echo e(asset("theme/assets/img/about/shipping3.png")); ?>" alt="">
                        </div>
                        <div class="shipping_content">
                            <h3><?php echo e($langJson->footer->payment_return); ?></h3>
                            <p><?php echo e($langJson->footer->return_day); ?></p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<!--shipping area end-->


<!--footer area start-->
<footer class="footer_widgets">
    <div class="container">

        <div class="footer_middle">
            <div class="row">
                <div class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4">
                    <div class="footer_social1 text-white">
                        <a href="<?php echo e(route("theme.{$langJson->routes->home}")); ?>"><img class="ml-3 mb-3 w-50"
                                                                                    src="<?php echo e(asset("storage/{$thisSetting->logo}")); ?>"
                                                                                    alt="<?php echo e($thisSetting->company_name); ?>"></a>
                        <p><?php echo e($thisSetting->slogan); ?></p>
                    </div>
                </div>
                <div class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4">
                    <div class="footer_social1">
                        <h4 class="text-uppercase text-left text-white mb-2 border-bottom pb-2 w-25"><?php echo e($langJson->menu->contact); ?></h4>
                        <ul class="list-unstyled ">
                            <li>
                                <a href="#!" class="text-white"> <?php echo e($thisSetting->company_name); ?>

                                </a>
                            </li>
                            <li>
                                <a href="#!" class="text-white"> <?php echo e($thisSetting->address); ?>

                                </a>
                            </li>
                            <li>
                                <a href="tel: <?php echo e($thisSetting->phone_1); ?>" class="text-white">
                                    <?php echo e($thisSetting->phone_1); ?>

                                </a>
                            </li>
                            <li>
                                <a href="tel: <?php echo e($thisSetting->phone_1); ?>" class="text-white">
                                    <?php echo e($thisSetting->phone_2); ?>

                                </a>
                            </li>
                            <li>
                                <a href="#!" class="text-white"> <?php echo e($thisSetting->email); ?></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4">
                    <div class="footer_social1">
                        <h4 class="text-uppercase text-left text-white mb-2 border-bottom pb-2 w-25"><?php echo e($langJson->menu->corporate); ?></h4>
                        <ul class="list-unstyled">
                            <?php $__currentLoopData = $viewData->corporates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $corporate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>

                                    <a href="<?php echo e(route("theme.{$langJson->routes->corporate}",$corporate->seo_url->$lang)); ?>"
                                       class="text-white"><?php echo e($corporate->title->$lang); ?></a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>

            </div>


        </div>
        <div class="footer_bottom">
            <div class="row align-items-center">
                <div class="col-lg-7 col-md-7">
                    <div class="footer_bottom_left">
                        <div class="footer_logo">
                            <a href="<?php echo e(route("theme.{$langJson->routes->home}")); ?>"><img class="ml-3 w-75"
                                                                                        src="<?php echo e(asset("storage/{$thisSetting->logo}")); ?>"
                                                                                        alt="<?php echo e($thisSetting->company_name); ?>"></a>
                        </div>
                        <div class="copyright_area">
                            <p>Copyright © 2021 <a href="index.html"><?php echo e($thisSetting->company_name); ?></a>. <a
                                    href="<?php echo e(route("theme.{$langJson->routes->home}")); ?>" target="_blank">Tüm Hakları
                                    Saklıdır.</a></p>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                    <div class="footer_social p-0 border-0">
                        <ul>
                            <?php if(!empty($thisSetting->facebook)): ?>
                                <li><a href="<?php echo e($thisSetting->facebook); ?>"><i class="fab fa-facebook "
                                                                            aria-hidden="true"></i></a></li>
                            <?php endif; ?>
                            <?php if(!empty($thisSetting->twitter)): ?>
                                <li><a href="<?php echo e($thisSetting->twitter); ?>"><i class="fab fa-twitter"
                                                                           aria-hidden="true"></i></a></li>
                            <?php endif; ?>
                            <?php if(!empty($thisSetting->youtube)): ?>
                                <li><a href="<?php echo e($thisSetting->youtube); ?>"><i class="fab fa-youtube"
                                                                           aria-hidden="true"></i></a></li>
                            <?php endif; ?>

                            <?php if(!empty($thisSetting->instagram)): ?>
                                <li><a href="<?php echo e($thisSetting->instagram); ?>"><i class="fab fa-instagram"
                                                                             aria-hidden="true"></i></a></li>
                            <?php endif; ?>

                        </ul>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3">
                    <div class="footer_paypal text-right">
                        <a href="https://mutfakyapim.com.tr"><img class="w-75" data-toggle="tooltip"
                                                                  data-placement="top"
                                                                  title="<?php echo e($langJson->footer->author); ?>"
                                                                  src="<?php echo e(asset("theme/assets/img/logo.png")); ?>"
                                                                  alt="<?php echo e($langJson->footer->author); ?>"></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!--footer area end-->


<!-- JS
============================================ -->
<!--jquery min js-->
<script src="<?php echo e(asset("theme/assets/js/vendor/jquery-3.4.1.min.js")); ?>"></script>
<!--popper min js-->

<script src="<?php echo e(asset("theme/assets/js/popper.js")); ?>"></script>
<!--bootstrap min js-->
<script src="<?php echo e(asset("theme/assets/js/bootstrap.min.js")); ?>"></script>
<!--owl carousel min js-->
<script src="<?php echo e(asset("theme/assets/js/owl.carousel.min.js")); ?>"></script>
<!--slick min js-->
<script src="<?php echo e(asset("theme/assets/js/slick.min.js")); ?>"></script>
<!--magnific popup min js-->
<script src="<?php echo e(asset("theme/assets/js/jquery.magnific-popup.min.js")); ?>"></script>
<!--jquery countdown min js-->
<script src="<?php echo e(asset("theme/assets/js/jquery.countdown.js")); ?>"></script>
<!--jquery ui min js-->
<script src="<?php echo e(asset("theme/assets/js/jquery.ui.js")); ?>"></script>
<!--jquery elevatezoom min js-->
<script src="<?php echo e(asset("theme/assets/js/jquery.elevatezoom.js")); ?>"></script>
<!--isotope packaged min js-->
<script src="<?php echo e(asset("theme/assets/js/isotope.pkgd.min.js")); ?>"></script>
<!-- Plugins JS -->
<script src="<?php echo e(asset("theme/assets/js/plugins.js")); ?>"></script>
<!-- iziToast JS -->
<script src="<?php echo e(asset("theme/assets/js/iziToast.js")); ?>"></script>
<script src="<?php echo e(asset("theme/assets/js/font-awesome.min.js")); ?>"></script>
<script src="<?php echo e(asset("theme/assets/js/jquery-ui.min.js")); ?>"></script>

<!-- Main JS -->
<script src="<?php echo e(asset("theme/assets/js/jquery-mask.min.js")); ?>"></script>
<script src="<?php echo e(asset("theme/assets/js/main.js")); ?>"></script>
<script src="<?php echo e(asset("theme/assets/js/script.js")); ?>"></script>


</body>
<?php echo $__env->yieldContent("footer"); ?>
<script>
    $(document).ready(function () {
        $(document).on("click", ".delete-cart-item", function () {
            let id = $(this).data("id")
            $.ajax({
                "url": "<?php echo e(route("theme.{$langJson->routes->basket_delete}")); ?>",
                "data": { "id": id},
                "type": "POST"
            }).done(function (response) {
                $(".delete-cart-item[data-id="+id+"]").parent().parent().hide("slow",function (){
                    $(".item_count").text(response.count)
                    $("#cart-render").html(response.data)
                    $(".mini_cart").addClass("active")
                });
                iziToast.success({
                    title: "<?php echo e($langJson->alert->success); ?>",
                    message: response.alert,
                    position: "topCenter",
                    displayMode: "once"
                });
            })
        })
    })
</script>
<?php if(\Illuminate\Support\Facades\Session::get("alert")): ?>
    <?php
        $data=\Illuminate\Support\Facades\Session::get("alert")
    ?>
    <script>
        iziToast.<?php echo e($data["status"]); ?>({
            title: "<?php echo e($data["title"]); ?>",
            message: "<?php echo e($data["msg"]); ?>",
            position: "topCenter"
        });
    </script>
<?php endif; ?>

</html>
<?php /**PATH C:\xampp\htdocs\unique\resources\views/theme/layouts/app.blade.php ENDPATH**/ ?>