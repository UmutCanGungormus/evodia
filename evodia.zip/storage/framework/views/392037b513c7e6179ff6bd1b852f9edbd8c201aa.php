<?php $__env->startSection("title",$langJson->menu->products); ?>
<?php $__env->startSection("header"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<?php $__env->startSection("menuClass","bg-dark"); ?>
<!--breadcrumbs area start-->
<div class="breadcrumbs_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_content">
                    <h3><?php echo e($search); ?></h3>
                    <ul>
                        <li><a href="index.html"><?php echo e($langJson->menu->home); ?></a></li>
                        <li><?php echo e($search); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!--breadcrumbs area end-->

<!--shop  area start-->
<div class="shop_area shop_reverse mb-80">
    <div class="container">
        <div class="row">

            <div class="col-12">
                <!--shop wrapper start-->

                <!--shop toolbar start-->
                <div class="shop_toolbar_wrapper">
                    <div class="shop_toolbar_btn">
                        <button data-role="grid_4" type="button" class="  btn-grid-4" data-toggle="tooltip"
                        ></button>
                        <button data-role="grid_3" type="button" class=" btn-grid-3" data-toggle="tooltip"
                        ></button>
                        <button data-role="grid_list" type="button" class="active btn-list" data-toggle="tooltip"
                        ></button>
                    </div>
                    <div class=" niceselect_option">
                        <select name="orderby" class="order-by form-control" id="short">
                            <option <?php echo e((Cookie::get("search_order")=="desc" && Cookie::get("search_column")=="id" ?"selected":"")); ?> value="id,desc"><?php echo e($langJson->select_order->new); ?></option>
                            <option <?php echo e((Cookie::get("search_order")=="asc" && Cookie::get("search_column")=="id" ?"selected":"")); ?> value="id,asc"><?php echo e($langJson->select_order->old); ?></option>
                            <option <?php echo e((Cookie::get("search_order")=="asc" && Cookie::get("search_column")=="price->{$lang}" ?"selected":"")); ?> value="price-><?php echo e($lang); ?>,asc"><?php echo e($langJson->select_order->cheap); ?></option>
                            <option <?php echo e((Cookie::get("search_order")=="desc" && Cookie::get("search_column")=="price->{$lang}" ?"selected":"")); ?> value="price-><?php echo e($lang); ?>,desc"><?php echo e($langJson->select_order->expensive); ?></option>
                        </select>
                    </div>
                    <div class="page_amount">
                        <p><?php echo e((empty($viewData->products->data)?"0":count((array)$viewData->products->data))); ?> <?php echo e($langJson->category->showing); ?></p>
                    </div>
                </div>
                <!--shop toolbar end-->
                <?php if(!empty($viewData->products->data )): ?>
                <div class="render-data">
                    <div class="row shop_wrapper grid_list">

                        <?php $__currentLoopData = $viewData->products->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-12">
                                <div class="single_product">
                                    <div class="product_thumb">
                                        <a class="primary_img" href="product-details.html">
                                            <img src="<?php echo e(asset("storage/{$product->cover_photo->img_url}")); ?>" alt=""></a>
                                        <?php if(!empty($product->isDisDisDiscount)): ?>
                                            <div class="label_product">
                                                <span class="label_sale"><?php echo e($langJson->home->discount); ?></span>
                                            </div>
                                        <?php endif; ?>
                                        <div class="action_links">
                                            <ul>
                                                <li class="quick_button"><a href="#" data-toggle="modal"
                                                                            data-target="#modal_box">
                                                        <span class="pe-7s-search"></span></a></li>
                                                <li class="wishlist"><a href="wishlist.html"><span
                                                            class="pe-7s-like"></span></a></li>

                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product_content grid_content">
                                        <div class="product_content_inner">
                                            <h4 class="product_name"><a
                                                    href="product-details.html"><?php echo e($product->title->$lang); ?></a></h4>
                                            <div class="price_box">
                                            <span
                                                class="current_price"><?php echo e($product->price->$lang); ?> <?php echo e($langJson->home->price); ?></span>
                                            </div>
                                        </div>
                                        <div class="add_to_cart">
                                            <a href="cart.html"><?php echo e($langJson->home->examine); ?></a>
                                        </div>
                                    </div>
                                    <div class="product_content list_content">
                                        <h4 class="product_name"><a
                                                href="product-details.html"><?php echo e($product->title->$lang); ?></a></h4>
                                        <div class="price_box">
                                        <span
                                            class="current_price"><?php echo e($product->price->$lang); ?> <?php echo e($langJson->home->price); ?></span>
                                        </div>

                                        <div class="product_desc">
                                            <p><?php echo e($product->description->$lang); ?></p>
                                        </div>
                                        <div class="add_to_cart shop_list_cart">
                                            <a href="cart.html"><?php echo e($langJson->home->examine); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>

                </div>
                <div class="shop_toolbar t_bottom">
                    <div class="pagination">
                        <ul>
                            <?php echo $links; ?>

                        </ul>
                    </div>
                </div>
            <?php else: ?>
                    <div class="alert alert-danger"><?php echo e($langJson->alert->no_product); ?></div>
                <?php endif; ?>
                <!--shop toolbar end-->
                <!--shop wrapper end-->
            </div>
        </div>
    </div>
</div>
<!--shop  area end-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection("footer"); ?>
    <script>
        $(document).ready(function () {
            $(document).on("change", ".order-by", function () {
                let value = $(this).val();
                value = value.split(",")
                setCookie("search_column",value[0]);
                setCookie("search_order",value[1])
                $.ajax({
                    "url": "<?php echo e(route("theme.{$langJson->routes->render_search}")); ?>",
                    "data": {"search_column": value[0], "search_order": value[1],"search":"<?php echo e($search); ?>"},
                    "type": "POST"
                }).done(function (response) {

                    $(".render-data").html(response)
                })
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\unique\resources\views/theme/search/index.blade.php ENDPATH**/ ?>