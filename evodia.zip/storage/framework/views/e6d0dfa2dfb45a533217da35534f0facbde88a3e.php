<?php $__env->startSection("title",$langJson->menu->corporate); ?>
<?php $__env->startSection("header"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<?php $__env->startSection("menuClass","bg-dark"); ?>
<!--breadcrumbs area start-->
<!--breadcrumbs area start-->
<div class="breadcrumbs_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_content">
                    <h3><?php echo e($langJson->login->login); ?> / <?php echo e($langJson->login->register); ?></h3>
                    <ul>
                        <li><a href="<?php echo e(route("theme.{$langJson->routes->home}")); ?>"><?php echo e($langJson->menu->home); ?></a></li>
                        <li><?php echo e($langJson->login->login); ?> / <?php echo e($langJson->login->register); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!--breadcrumbs area end-->

<!-- customer login start -->
<div class="customer_login">
    <div class="container">
        <div class="row">
            <!--login area start-->
            <div class="col-lg-6 col-md-6">
                <div class="account_form">
                    <h2><?php echo e($langJson->login->login); ?></h2>
                    <form onsubmit="return false;">
                        <?php echo csrf_field(); ?>
                        <p>
                            <label><?php echo e($langJson->login->email); ?> <span>*</span></label>
                            <input id="login-email" name="email" type="text">
                        </p>
                        <p>
                            <label><?php echo e($langJson->login->password); ?> <span>*</span></label>
                            <input id="login-pass" name="password" type="password">
                        </p>
                        <div class="login_submit">
                            <a href="#"><?php echo e($langJson->login->forgot_password); ?></a>
                            <button id="login-btn" type="button"><?php echo e($langJson->login->login); ?></button>
                        </div>
                    </form>
                </div>
            </div>
            <!--login area start-->

            <!--register area start-->
            <div class="col-lg-6 col-md-6">
                <div class="account_form register">
                    <h2><?php echo e($langJson->login->register); ?></h2>
                    <form action="#">
                        <?php echo csrf_field(); ?>
                        <p>
                            <label><?php echo e($langJson->login->full_name); ?> <span>*</span></label>
                            <input id="register-full_name" name="full_name" type="text">
                        </p>
                        <p>
                            <label><?php echo e($langJson->login->phone); ?> <span>*</span></label>
                            <input id="register-phone" class="phone-number" name="phone" type="text">
                        </p>

                        <p>
                            <label><?php echo e($langJson->login->email); ?> <span>*</span></label>
                            <input id="register-email" name="email" type="text">
                        </p>
                        <p>
                            <label><?php echo e($langJson->login->user_name); ?> </label>
                            <input id="register-user_name" name="user_name" type="text">
                        </p>
                        <p>
                            <label><?php echo e($langJson->login->password); ?> <span>*</span></label>
                            <input id="register-pass" name="password" type="password">
                        </p>
                        <p>
                            <label><?php echo e($langJson->login->confirm_password); ?> <span>*</span></label>
                            <input id="register-confirm_password" name="confirm_password" type="password">
                        </p>

                        <div class="login_submit">
                            <button id="register-btn" type="button"><?php echo e($langJson->login->register); ?></button>
                        </div>
                    </form>
                </div>
            </div>
            <!--register area end-->
        </div>
    </div>
</div>
<!-- customer login end -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection("footer"); ?>
    <script>
        $(document).ready(function (data) {
            data.mask.definitions['~'] = '[+-]';
            $('.phone-number').mask('0999 999 9999');
        })
        $(document).ready(function () {
            $(document).on("click", "#login-btn", function () {
                let email = $("#login-email").val();
                let pass = $("#login-pass").val();
                let control = 1;
                if (email === "" || email === "undefined" || email === null || !isEmail(email)) {
                    iziToast.error({
                        title: "<?php echo e($langJson->alert->error); ?>",
                        message: "<?php echo e($langJson->login->email." ".$langJson->alert->null); ?>",
                        position: "topCenter"
                    });
                    control = 0;
                }
                if (pass === "" || pass === "undefined" || pass === null) {
                    iziToast.error({
                        title: "<?php echo e($langJson->alert->error); ?>",
                        message: "<?php echo e($langJson->login->password." ".$langJson->alert->null); ?>",
                        position: "topCenter"
                    });
                    control = 0;
                }
                if (control === 1) {
                    $.ajax({
                        "url": "<?php echo e(route("theme.{$langJson->routes->login}")); ?>",
                        "data": {"email": email, "password": pass},
                        "type": "POST"
                    }).done(function (response) {
                        if (response.success) {
                            iziToast.success({
                                title: response.title,
                                message: response.msg,
                                position: "topCenter"
                            });
                            if (response.url !== "" || response.url !== "undefined" || response.url !== null) {
                                setTimeout(function () {
                                    window.location.href = response.url
                                }, 2000);

                            }
                        } else {
                            iziToast.error({
                                title: response.title,
                                message: response.msg,
                                position: "topCenter"
                            });
                        }
                    })
                }
            })
            $(document).on("click", "#register-btn", function () {
                let email = $("#register-email").val();
                let pass = $("#register-pass").val();
                let username = $("#register-user_name").val();
                let full_name = $("#register-full_name").val();
                let phone = $("#register-phone").val();
                let confirmpass = $("#register-confirm_password").val();
                let control = 1;
                if (email === "" || email === "undefined" || email === null || !isEmail(email)) {
                    iziToast.error({
                        title: "<?php echo e($langJson->alert->error); ?>",
                        message: "<?php echo e($langJson->login->email." ".$langJson->alert->null); ?>",
                        position: "topCenter"
                    });
                    control = 0;
                }
                if (pass === "" || pass === "undefined" || pass === null) {
                    iziToast.error({
                        title: "<?php echo e($langJson->alert->error); ?>",
                        message: "<?php echo e($langJson->login->password." ".$langJson->alert->null); ?>",
                        position: "topCenter"
                    });
                    control = 0;
                }
                if (full_name === "" || full_name === "undefined" || full_name === null) {
                    iziToast.error({
                        title: "<?php echo e($langJson->alert->error); ?>",
                        message: "<?php echo e($langJson->login->full_name." ".$langJson->alert->null); ?>",
                        position: "topCenter"
                    });
                    control = 0;
                }
                if (phone === "" || phone === "undefined" || phone === null) {
                    iziToast.error({
                        title: "<?php echo e($langJson->alert->error); ?>",
                        message: "<?php echo e($langJson->login->phone." ".$langJson->alert->null); ?>",
                        position: "topCenter"
                    });
                    control = 0;
                }
                if (confirmpass === "" || confirmpass === "undefined" || confirmpass === null) {
                    iziToast.error({
                        title: "<?php echo e($langJson->alert->error); ?>",
                        message: "<?php echo e($langJson->login->phone." ".$langJson->alert->null); ?>",
                        position: "topCenter"
                    });
                    control = 0;
                }
                if(confirmpass!==pass){
                    iziToast.error({
                        title: "<?php echo e($langJson->alert->error); ?>",
                        message: "<?php echo e($langJson->login->password." & ".$langJson->login->confirm_password ." ". $langJson->alert->not_mach); ?>",
                        position: "topCenter"
                    });
                    control = 0;
                }
                if (control === 1) {
                    $.ajax({
                        "url": "<?php echo e(route("theme.{$langJson->routes->register}")); ?>",
                        "data": {"email": email, "password": pass,"password_confirmation":confirmpass,"user_name":username,"phone":phone,"full_name":full_name},
                        "type": "POST",
                        "dataType": "json"
                    }).done(function (response) {
                        if (response.success) {
                            iziToast.success({
                                title: response.title,
                                message: response.msg,
                                position: "topCenter"
                            });
                            if (response.url !== "" || response.url !== "undefined" || response.url !== null) {
                                setTimeout(function () {
                                    window.location.href = response.url
                                }, 2000);

                            }
                        } else {
                            iziToast.error({
                                title: response.title,
                                message: response.msg,
                                position: "topCenter"
                            });
                        }
                    })
                }
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\unique\resources\views/theme/login/index.blade.php ENDPATH**/ ?>