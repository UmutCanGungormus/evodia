<?php $__env->startSection("title",$langJson->menu->corporate); ?>
<?php $__env->startSection("header"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>


<!-- Page Banner Section Start -->
<div class="page-banner-section section bg-image" data-bg="assets/images/bg/breadcrumb.png">
    <div class="container">
        <div class="row">
            <div class="col">

                <div class="page-banner text-left">
                    <h2><?php echo e($viewData->item->title->$lang); ?></h2>
                    <ul class="page-breadcrumb">
                        <li><a  href="<?php echo e(route("theme.{$langJson->routes->home}")); ?>"><?php echo e($langJson->menu->home); ?></a></li>
                        <li><?php echo e($viewData->item->title->$lang); ?></li>
                    </ul>
                </div>

            </div>
        </div>
    </div>
</div>
<!-- Page Banner Section End -->
<!--Blog section start-->
<div class="blog-section section pt-90 pt-lg-70 pt-md-60 pt-sm-50 pt-xs-40 pb-100 pb-lg-80 pb-md-70 pb-sm-60 pb-xs-50">
    <div class="container">
        <div class="row">
            <div class="col-lg-12  mb-sm-40 mb-xs-30 pl-40 pl-md-15 pl-sm-15 pl-xs-15">
                <div class="row">
                    <div class="blog-details col-12">
                        <div class="blog-inner">
                            <div class="blog-media">
                                <div class="image"><img src="<?php echo e(asset("storage/{$viewData->item->img_url->$lang}")); ?>" alt="<?php echo e($viewData->item->title->$lang); ?>"></div>
                            </div>
                            <div class="content">

                                <h2 class="title"><?php echo e($viewData->item->title->$lang); ?></h2>
                                <div class="desc mb-30">

                                    <blockquote class="blockquote mt-30 mb-30">
                                        <p><?php echo e($viewData->item->description->$lang); ?></p>
                                        <span class="author"><?php echo e($thisSetting->company_name); ?></span>
                                    </blockquote>


                                </div>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<!--Blog section end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\evodia\resources\views/theme/corporate/index.blade.php ENDPATH**/ ?>