<?php

namespace App\Http\Controllers\Theme\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class indexController extends Controller
{
    //
}
